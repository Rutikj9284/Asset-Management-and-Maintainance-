package com.assettrak;

import com.assettrak.model.*;
import com.assettrak.service.*;
import com.assettrak.util.DataSeeder;
import com.assettrak.util.InputHelper;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

/**
 * AssetTrak - Console Application (Sprint 1)
 * Standalone Java console app for Asset Management & Maintenance Tracking.
 * Role-based access (Admin / Employee) is simulated via employee login,
 * since Spring Security is planned for Sprint 2.
 */
public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final InputHelper input = new InputHelper(scanner);

    private static final EmployeeService employeeService = new EmployeeService();
    private static final AssetService assetService = new AssetService();
    private static final AssignmentService assignmentService = new AssignmentService(assetService);
    private static final MaintenanceService maintenanceService = new MaintenanceService(assetService);

    private static Employee currentUser;

    public static void main(String[] args) {
        DataSeeder.seed(employeeService, assetService, assignmentService, maintenanceService);

        System.out.println("=========================================");
        System.out.println("   Welcome to AssetTrak Console App");
        System.out.println("=========================================");

        boolean running = true;
        while (running) {
            if (currentUser == null) {
                running = login();
            } else if (currentUser.getRole() == Role.ADMIN) {
                adminMenu();
            } else {
                employeeMenu();
            }
        }

        System.out.println("\nGoodbye!");
        scanner.close();
    }

    // ---------- LOGIN ----------

    private static boolean login() {
        System.out.println("\n--- Login ---");
        System.out.println("Available Employee IDs:");
        for (Employee e : employeeService.getAll()) {
            System.out.println("  " + e.getId() + " - " + e.getName() + " (" + e.getRole() + ")");
        }
        int id = input.readInt("Enter your Employee ID (0 to exit): ");
        if (id == 0) return false;

        Optional<Employee> emp = employeeService.getById(id);
        if (emp.isEmpty()) {
            System.out.println("No employee found with that ID.");
            return true;
        }
        currentUser = emp.get();
        System.out.println("Logged in as " + currentUser.getName() + " (" + currentUser.getRole() + ")");
        return true;
    }

    private static void logout() {
        System.out.println("Logging out " + currentUser.getName() + "...");
        currentUser = null;
    }

    // ---------- ADMIN MENU ----------

    private static void adminMenu() {
        System.out.println("\n===== ADMIN MENU (" + currentUser.getName() + ") =====");
        System.out.println("1. Manage Assets");
        System.out.println("2. Manage Employees");
        System.out.println("3. Manage Assignments");
        System.out.println("4. Manage Maintenance Requests");
        System.out.println("5. View Reports");
        System.out.println("0. Logout");
        int choice = input.readIntInRange("Choose an option: ", 0, 5);

        switch (choice) {
            case 1 -> assetMenu();
            case 2 -> employeeMenu_admin();
            case 3 -> assignmentMenu();
            case 4 -> maintenanceMenu_admin();
            case 5 -> reportsMenu();
            case 0 -> logout();
        }
    }

    // --- Asset management (Admin) ---
    private static void assetMenu() {
        System.out.println("\n--- Manage Assets ---");
        System.out.println("1. Add Asset");
        System.out.println("2. View All Assets");
        System.out.println("3. Update Asset");
        System.out.println("4. Delete Asset");
        System.out.println("0. Back");
        int choice = input.readIntInRange("Choose an option: ", 0, 4);

        switch (choice) {
            case 1 -> {
                String name = input.readLine("Asset name: ");
                String category = input.readLine("Category: ");
                String serial = input.readLine("Serial number: ");
                LocalDate purchaseDate = input.readDate("Purchase date");
                String location = input.readLine("Location: ");
                Asset a = assetService.addAsset(name, category, serial, purchaseDate, location);
                System.out.println("Added: " + a);
            }
            case 2 -> printList(assetService.getAll(), "assets");
            case 3 -> {
                int id = input.readInt("Enter Asset ID to update: ");
                Optional<Asset> aOpt = assetService.getById(id);
                if (aOpt.isEmpty()) {
                    System.out.println("Asset not found.");
                    break;
                }
                Asset a = aOpt.get();
                a.setName(input.readLine("New name (" + a.getName() + "): "));
                a.setCategory(input.readLine("New category (" + a.getCategory() + "): "));
                a.setLocation(input.readLine("New location (" + a.getLocation() + "): "));
                System.out.println("Updated: " + a);
            }
            case 4 -> {
                int id = input.readInt("Enter Asset ID to delete: ");
                boolean removed = assetService.deleteById(id);
                System.out.println(removed ? "Asset deleted." : "Asset not found.");
            }
            case 0 -> { }
        }
    }

    // --- Employee management (Admin) ---
    private static void employeeMenu_admin() {
        System.out.println("\n--- Manage Employees ---");
        System.out.println("1. Add Employee");
        System.out.println("2. View All Employees");
        System.out.println("3. Delete Employee");
        System.out.println("0. Back");
        int choice = input.readIntInRange("Choose an option: ", 0, 3);

        switch (choice) {
            case 1 -> {
                String name = input.readLine("Name: ");
                String email = input.readLine("Email: ");
                String dept = input.readLine("Department: ");
                boolean isAdmin = input.readYesNo("Is this employee an Admin?");
                Employee e = employeeService.addEmployee(name, email, dept, isAdmin ? Role.ADMIN : Role.EMPLOYEE);
                System.out.println("Added: " + e);
            }
            case 2 -> printList(employeeService.getAll(), "employees");
            case 3 -> {
                int id = input.readInt("Enter Employee ID to delete: ");
                if (currentUser.getId() == id) {
                    System.out.println("You cannot delete your own account while logged in.");
                    break;
                }
                boolean removed = employeeService.deleteById(id);
                System.out.println(removed ? "Employee deleted." : "Employee not found.");
            }
            case 0 -> { }
        }
    }

    // --- Assignment management (Admin) ---
    private static void assignmentMenu() {
        System.out.println("\n--- Manage Assignments ---");
        System.out.println("1. Assign Asset to Employee");
        System.out.println("2. Return Asset");
        System.out.println("3. View All Assignments");
        System.out.println("0. Back");
        int choice = input.readIntInRange("Choose an option: ", 0, 3);

        switch (choice) {
            case 1 -> {
                printList(assetService.getByStatus(AssetStatus.AVAILABLE), "available assets");
                int assetId = input.readInt("Enter Asset ID to assign: ");
                printList(employeeService.getAll(), "employees");
                int empId = input.readInt("Enter Employee ID to assign to: ");
                LocalDate date = input.readDate("Assignment date");
                Optional<Assignment> result = assignmentService.assignAsset(assetId, empId, date);
                if (result.isPresent()) {
                    System.out.println("Assigned: " + result.get());
                } else {
                    System.out.println("Could not assign. Check that the Asset ID exists and is AVAILABLE.");
                }
            }
            case 2 -> {
                printList(assignmentService.getAll(), "assignments");
                int assignmentId = input.readInt("Enter Assignment ID to return: ");
                LocalDate date = input.readDate("Return date");
                boolean ok = assignmentService.returnAsset(assignmentId, date);
                System.out.println(ok ? "Asset returned." : "Could not return — check the assignment ID and that it's still ACTIVE.");
            }
            case 3 -> printList(assignmentService.getAll(), "assignments");
            case 0 -> { }
        }
    }

    // --- Maintenance management (Admin) ---
    private static void maintenanceMenu_admin() {
        System.out.println("\n--- Manage Maintenance Requests ---");
        System.out.println("1. View All Requests");
        System.out.println("2. Update Request Status");
        System.out.println("0. Back");
        int choice = input.readIntInRange("Choose an option: ", 0, 2);

        switch (choice) {
            case 1 -> printList(maintenanceService.getAll(), "maintenance requests");
            case 2 -> {
                printList(maintenanceService.getAll(), "maintenance requests");
                int id = input.readInt("Enter Maintenance Request ID to update: ");
                System.out.println("Set status to: 1. PENDING  2. IN_PROGRESS  3. COMPLETED");
                int statusChoice = input.readIntInRange("Choose: ", 1, 3);
                MaintenanceStatus status = switch (statusChoice) {
                    case 1 -> MaintenanceStatus.PENDING;
                    case 2 -> MaintenanceStatus.IN_PROGRESS;
                    default -> MaintenanceStatus.COMPLETED;
                };
                LocalDate resolvedDate = status == MaintenanceStatus.COMPLETED
                        ? input.readDate("Resolved date") : null;
                boolean ok = maintenanceService.updateStatus(id, status, resolvedDate);
                System.out.println(ok ? "Status updated." : "Request not found.");
            }
            case 0 -> { }
        }
    }

    // --- Reports (Admin) ---
    private static void reportsMenu() {
        System.out.println("\n--- Reports ---");
        System.out.println("1. Assets by Status Summary");
        System.out.println("2. All Active Assignments");
        System.out.println("3. Pending Maintenance Requests");
        System.out.println("0. Back");
        int choice = input.readIntInRange("Choose an option: ", 0, 3);

        switch (choice) {
            case 1 -> {
                for (AssetStatus status : AssetStatus.values()) {
                    long count = assetService.getByStatus(status).size();
                    System.out.printf("%-18s: %d%n", status, count);
                }
            }
            case 2 -> {
                List<Assignment> active = assignmentService.getAll().stream()
                        .filter(a -> a.getStatus() == AssignmentStatus.ACTIVE)
                        .toList();
                printList(active, "active assignments");
            }
            case 3 -> {
                List<Maintenance> pending = maintenanceService.getAll().stream()
                        .filter(m -> m.getStatus() != MaintenanceStatus.COMPLETED)
                        .toList();
                printList(pending, "pending maintenance requests");
            }
            case 0 -> { }
        }
    }

    // ---------- EMPLOYEE MENU ----------

    private static void employeeMenu() {
        System.out.println("\n===== EMPLOYEE MENU (" + currentUser.getName() + ") =====");
        System.out.println("1. View Available Assets");
        System.out.println("2. View My Assigned Assets");
        System.out.println("3. Report a Maintenance Issue");
        System.out.println("4. View My Maintenance Requests");
        System.out.println("0. Logout");
        int choice = input.readIntInRange("Choose an option: ", 0, 4);

        switch (choice) {
            case 1 -> printList(assetService.getByStatus(AssetStatus.AVAILABLE), "available assets");
            case 2 -> {
                List<Assignment> mine = assignmentService.getByEmployeeId(currentUser.getId());
                printList(mine, "your assignments");
            }
            case 3 -> {
                List<Assignment> mine = assignmentService.getByEmployeeId(currentUser.getId()).stream()
                        .filter(a -> a.getStatus() == AssignmentStatus.ACTIVE)
                        .toList();
                if (mine.isEmpty()) {
                    System.out.println("You have no currently assigned assets to report an issue for.");
                    break;
                }
                printList(mine, "your active assignments");
                int assetId = input.readInt("Enter Asset ID to report an issue for: ");
                boolean isMine = mine.stream().anyMatch(a -> a.getAssetId() == assetId);
                if (!isMine) {
                    System.out.println("That asset is not currently assigned to you.");
                    break;
                }
                String description = input.readLine("Describe the issue: ");
                LocalDate date = input.readDate("Reported date");
                Optional<Maintenance> result = maintenanceService.reportIssue(
                        assetId, currentUser.getId(), description, date);
                System.out.println(result.isPresent() ? "Issue reported: " + result.get() : "Could not report issue.");
            }
            case 4 -> {
                List<Maintenance> mine = maintenanceService.getByEmployeeId(currentUser.getId());
                printList(mine, "your maintenance requests");
            }
            case 0 -> logout();
        }
    }

    // ---------- HELPERS ----------

    private static <T> void printList(List<T> items, String label) {
        if (items.isEmpty()) {
            System.out.println("No " + label + " found.");
            return;
        }
        System.out.println("\n-- " + label + " (" + items.size() + ") --");
        for (T item : items) {
            System.out.println(item);
        }
    }
}
