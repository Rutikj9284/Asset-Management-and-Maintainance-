package com.assettrak.model;

public enum AssignmentStatus {
    ACTIVE,
    RETURNED
}
