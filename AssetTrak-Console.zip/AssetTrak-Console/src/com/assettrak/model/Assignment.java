package com.assettrak.model;

import java.time.LocalDate;

public class Assignment {
    private int id;
    private int assetId;
    private int employeeId;
    private LocalDate assignedDate;
    private LocalDate returnDate;
    private AssignmentStatus status;

    public Assignment(int id, int assetId, int employeeId, LocalDate assignedDate,
                       LocalDate returnDate, AssignmentStatus status) {
        this.id = id;
        this.assetId = assetId;
        this.employeeId = employeeId;
        this.assignedDate = assignedDate;
        this.returnDate = returnDate;
        this.status = status;
    }

    public int getId() { return id; }
    public int getAssetId() { return assetId; }
    public int getEmployeeId() { return employeeId; }
    public LocalDate getAssignedDate() { return assignedDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }
    public AssignmentStatus getStatus() { return status; }
    public void setStatus(AssignmentStatus status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | AssetID: %-5d | EmployeeID: %-5d | Assigned: %-12s | Returned: %-12s | %s",
                id, assetId, employeeId, assignedDate,
                (returnDate == null ? "-" : returnDate), status);
    }
}
