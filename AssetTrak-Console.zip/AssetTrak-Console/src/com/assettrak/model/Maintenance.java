package com.assettrak.model;

import java.time.LocalDate;

public class Maintenance {
    private int id;
    private int assetId;
    private int reportedByEmployeeId;
    private String issueDescription;
    private LocalDate reportedDate;
    private LocalDate resolvedDate;
    private MaintenanceStatus status;

    public Maintenance(int id, int assetId, int reportedByEmployeeId, String issueDescription,
                        LocalDate reportedDate, LocalDate resolvedDate, MaintenanceStatus status) {
        this.id = id;
        this.assetId = assetId;
        this.reportedByEmployeeId = reportedByEmployeeId;
        this.issueDescription = issueDescription;
        this.reportedDate = reportedDate;
        this.resolvedDate = resolvedDate;
        this.status = status;
    }

    public int getId() { return id; }
    public int getAssetId() { return assetId; }
    public int getReportedByEmployeeId() { return reportedByEmployeeId; }
    public String getIssueDescription() { return issueDescription; }
    public LocalDate getReportedDate() { return reportedDate; }
    public LocalDate getResolvedDate() { return resolvedDate; }
    public void setResolvedDate(LocalDate resolvedDate) { this.resolvedDate = resolvedDate; }
    public MaintenanceStatus getStatus() { return status; }
    public void setStatus(MaintenanceStatus status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | AssetID: %-5d | ReportedBy: %-5d | %-25s | Reported: %-12s | Resolved: %-12s | %s",
                id, assetId, reportedByEmployeeId, issueDescription, reportedDate,
                (resolvedDate == null ? "-" : resolvedDate), status);
    }
}
