package com.assettrak.model;

public enum AssetStatus {
    AVAILABLE,
    ASSIGNED,
    UNDER_MAINTENANCE,
    RETIRED
}
