package com.assettrak.model;

public enum MaintenanceStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
