package com.assettrak.model;

public class Employee {
    private int id;
    private String name;
    private String email;
    private String department;
    private Role role;

    public Employee(int id, String name, String email, String department, Role role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.department = department;
        this.role = role;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | %-20s | %-25s | %-15s | %s",
                id, name, email, department, role);
    }
}
