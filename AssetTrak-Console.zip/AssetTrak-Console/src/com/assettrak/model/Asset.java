package com.assettrak.model;

import java.time.LocalDate;

public class Asset {
    private int id;
    private String name;
    private String category;
    private String serialNumber;
    private LocalDate purchaseDate;
    private String location;
    private AssetStatus status;

    public Asset(int id, String name, String category, String serialNumber,
                 LocalDate purchaseDate, String location, AssetStatus status) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.serialNumber = serialNumber;
        this.purchaseDate = purchaseDate;
        this.location = location;
        this.status = status;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getSerialNumber() { return serialNumber; }
    public void setSerialNumber(String serialNumber) { this.serialNumber = serialNumber; }
    public LocalDate getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(LocalDate purchaseDate) { this.purchaseDate = purchaseDate; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public AssetStatus getStatus() { return status; }
    public void setStatus(AssetStatus status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | %-18s | %-12s | SN: %-12s | %-10s | %-12s | %s",
                id, name, category, serialNumber, status, location, purchaseDate);
    }
}
