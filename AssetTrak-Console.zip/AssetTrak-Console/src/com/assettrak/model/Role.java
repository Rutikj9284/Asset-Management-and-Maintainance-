package com.assettrak.model;

public enum Role {
    ADMIN,
    EMPLOYEE
}
