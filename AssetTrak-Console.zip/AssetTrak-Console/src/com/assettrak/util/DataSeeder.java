package com.assettrak.util;

import com.assettrak.model.Role;
import com.assettrak.service.AssetService;
import com.assettrak.service.AssignmentService;
import com.assettrak.service.EmployeeService;
import com.assettrak.service.MaintenanceService;

import java.time.LocalDate;

/** Populates sample data so the app can be demoed/tested without manual entry first. */
public class DataSeeder {

    public static void seed(EmployeeService employeeService, AssetService assetService,
                             AssignmentService assignmentService, MaintenanceService maintenanceService) {

        employeeService.addEmployee("Alice Sharma", "alice.sharma@company.com", "IT Admin", Role.ADMIN);
        employeeService.addEmployee("Ravi Kumar", "ravi.kumar@company.com", "Engineering", Role.EMPLOYEE);
        employeeService.addEmployee("Priya Nair", "priya.nair@company.com", "Marketing", Role.EMPLOYEE);

        assetService.addAsset("Dell Latitude 5420", "Laptop", "SN-LT-1001",
                LocalDate.of(2024, 3, 15), "Store Room A");
        assetService.addAsset("HP LaserJet Pro", "Printer", "SN-PR-2002",
                LocalDate.of(2023, 11, 1), "Floor 2 - IT");
        assetService.addAsset("Logitech MX Master 3", "Peripheral", "SN-MS-3003",
                LocalDate.of(2024, 6, 20), "Store Room A");
        assetService.addAsset("Dell Latitude 5420 (Unit 2)", "Laptop", "SN-LT-1002",
                LocalDate.of(2024, 3, 15), "Store Room A");

        // Assign asset 1 to employee 2, and asset 2 to employee 3
        assignmentService.assignAsset(1, 2, LocalDate.of(2025, 1, 10));
        assignmentService.assignAsset(2, 3, LocalDate.of(2025, 2, 5));

        // Report an issue on asset 3
        maintenanceService.reportIssue(3, 2, "Scroll wheel not responding", LocalDate.of(2025, 5, 1));
    }
}
