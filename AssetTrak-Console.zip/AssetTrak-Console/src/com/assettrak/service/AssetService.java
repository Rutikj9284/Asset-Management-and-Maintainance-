package com.assettrak.service;

import com.assettrak.model.Asset;
import com.assettrak.model.AssetStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AssetService {
    private final List<Asset> assets = new ArrayList<>();
    private int nextId = 1;

    public Asset addAsset(String name, String category, String serialNumber,
                           LocalDate purchaseDate, String location) {
        Asset asset = new Asset(nextId++, name, category, serialNumber,
                purchaseDate, location, AssetStatus.AVAILABLE);
        assets.add(asset);
        return asset;
    }

    public List<Asset> getAll() {
        return assets;
    }

    public List<Asset> getByStatus(AssetStatus status) {
        List<Asset> result = new ArrayList<>();
        for (Asset a : assets) {
            if (a.getStatus() == status) result.add(a);
        }
        return result;
    }

    public Optional<Asset> getById(int id) {
        return assets.stream().filter(a -> a.getId() == id).findFirst();
    }

    public boolean deleteById(int id) {
        return assets.removeIf(a -> a.getId() == id);
    }

    public boolean existsById(int id) {
        return getById(id).isPresent();
    }
}
