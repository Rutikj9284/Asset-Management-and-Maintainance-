package com.assettrak.service;

import com.assettrak.model.Assignment;
import com.assettrak.model.AssignmentStatus;
import com.assettrak.model.Asset;
import com.assettrak.model.AssetStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AssignmentService {
    private final List<Assignment> assignments = new ArrayList<>();
    private int nextId = 1;
    private final AssetService assetService;

    public AssignmentService(AssetService assetService) {
        this.assetService = assetService;
    }

    /** Returns empty if the asset isn't AVAILABLE or doesn't exist. */
    public Optional<Assignment> assignAsset(int assetId, int employeeId, LocalDate assignedDate) {
        Optional<Asset> assetOpt = assetService.getById(assetId);
        if (assetOpt.isEmpty() || assetOpt.get().getStatus() != AssetStatus.AVAILABLE) {
            return Optional.empty();
        }
        Asset asset = assetOpt.get();
        asset.setStatus(AssetStatus.ASSIGNED);

        Assignment assignment = new Assignment(nextId++, assetId, employeeId,
                assignedDate, null, AssignmentStatus.ACTIVE);
        assignments.add(assignment);
        return Optional.of(assignment);
    }

    public boolean returnAsset(int assignmentId, LocalDate returnDate) {
        Optional<Assignment> assignmentOpt = getById(assignmentId);
        if (assignmentOpt.isEmpty() || assignmentOpt.get().getStatus() != AssignmentStatus.ACTIVE) {
            return false;
        }
        Assignment assignment = assignmentOpt.get();
        assignment.setReturnDate(returnDate);
        assignment.setStatus(AssignmentStatus.RETURNED);

        assetService.getById(assignment.getAssetId())
                .ifPresent(a -> a.setStatus(AssetStatus.AVAILABLE));
        return true;
    }

    public List<Assignment> getAll() {
        return assignments;
    }

    public List<Assignment> getByEmployeeId(int employeeId) {
        List<Assignment> result = new ArrayList<>();
        for (Assignment a : assignments) {
            if (a.getEmployeeId() == employeeId) result.add(a);
        }
        return result;
    }

    public Optional<Assignment> getById(int id) {
        return assignments.stream().filter(a -> a.getId() == id).findFirst();
    }
}
