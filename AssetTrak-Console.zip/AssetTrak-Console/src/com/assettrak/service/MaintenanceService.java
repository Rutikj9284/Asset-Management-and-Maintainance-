package com.assettrak.service;

import com.assettrak.model.Maintenance;
import com.assettrak.model.MaintenanceStatus;
import com.assettrak.model.Asset;
import com.assettrak.model.AssetStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MaintenanceService {
    private final List<Maintenance> requests = new ArrayList<>();
    private int nextId = 1;
    private final AssetService assetService;

    public MaintenanceService(AssetService assetService) {
        this.assetService = assetService;
    }

    /** Returns empty if the asset doesn't exist. */
    public Optional<Maintenance> reportIssue(int assetId, int reportedByEmployeeId,
                                              String issueDescription, LocalDate reportedDate) {
        Optional<Asset> assetOpt = assetService.getById(assetId);
        if (assetOpt.isEmpty()) return Optional.empty();

        assetOpt.get().setStatus(AssetStatus.UNDER_MAINTENANCE);

        Maintenance m = new Maintenance(nextId++, assetId, reportedByEmployeeId,
                issueDescription, reportedDate, null, MaintenanceStatus.PENDING);
        requests.add(m);
        return Optional.of(m);
    }

    public boolean updateStatus(int maintenanceId, MaintenanceStatus newStatus, LocalDate resolvedDate) {
        Optional<Maintenance> mOpt = getById(maintenanceId);
        if (mOpt.isEmpty()) return false;
        Maintenance m = mOpt.get();
        m.setStatus(newStatus);

        if (newStatus == MaintenanceStatus.COMPLETED) {
            m.setResolvedDate(resolvedDate);
            assetService.getById(m.getAssetId())
                    .ifPresent(a -> a.setStatus(AssetStatus.AVAILABLE));
        }
        return true;
    }

    public List<Maintenance> getAll() {
        return requests;
    }

    public List<Maintenance> getByAssetId(int assetId) {
        List<Maintenance> result = new ArrayList<>();
        for (Maintenance m : requests) {
            if (m.getAssetId() == assetId) result.add(m);
        }
        return result;
    }

    public List<Maintenance> getByEmployeeId(int employeeId) {
        List<Maintenance> result = new ArrayList<>();
        for (Maintenance m : requests) {
            if (m.getReportedByEmployeeId() == employeeId) result.add(m);
        }
        return result;
    }

    public Optional<Maintenance> getById(int id) {
        return requests.stream().filter(m -> m.getId() == id).findFirst();
    }
}
