package com.assettrak.service;

import com.assettrak.model.Employee;
import com.assettrak.model.Role;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EmployeeService {
    private final List<Employee> employees = new ArrayList<>();
    private int nextId = 1;

    public Employee addEmployee(String name, String email, String department, Role role) {
        Employee employee = new Employee(nextId++, name, email, department, role);
        employees.add(employee);
        return employee;
    }

    public List<Employee> getAll() {
        return employees;
    }

    public Optional<Employee> getById(int id) {
        return employees.stream().filter(e -> e.getId() == id).findFirst();
    }

    public boolean deleteById(int id) {
        return employees.removeIf(e -> e.getId() == id);
    }

    public boolean existsById(int id) {
        return getById(id).isPresent();
    }
}
