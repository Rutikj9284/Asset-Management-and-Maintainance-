# AssetTrak – Console Application (Sprint 1)

A standalone Java console app for Asset Management & Maintenance Tracking, built for the TCS ILP project.

## Entities
- **Employee** – id, name, email, department, role (ADMIN / EMPLOYEE)
- **Asset** – id, name, category, serial number, purchase date, location, status
- **Assignment** – links an Asset to an Employee, tracks assigned/returned dates
- **Maintenance** – issue reports against an Asset, tracks status (PENDING → IN_PROGRESS → COMPLETED)

## Role-Based Access
Login is simulated by entering an Employee ID (real authentication with Spring Security comes in Sprint 2).

**Admin** can:
- Manage Assets (add/view/update/delete)
- Manage Employees (add/view/delete)
- Manage Assignments (assign/return assets)
- Manage Maintenance Requests (view/update status)
- View Reports (status summary, active assignments, pending maintenance)

**Employee** can:
- View available assets
- View their own assigned assets
- Report a maintenance issue on an asset assigned to them
- View their own maintenance requests

## How to Run
Requires JDK 17+.

```bash
cd src
javac -encoding UTF-8 -d ../bin $(find . -name "*.java")
cd ..
java -cp bin com.assettrak.Main
```

Sample data (3 employees, 4 assets, 2 assignments, 1 maintenance request) is seeded automatically on startup — try logging in as Employee ID `1` (Alice Sharma, Admin) or `2` (Ravi Kumar, Employee).

## Project Structure
```
src/com/assettrak/
├── Main.java              # Entry point, login, role-based menus
├── model/                 # Asset, Employee, Assignment, Maintenance + status enums
├── service/                # In-memory CRUD/business logic per entity
└── util/                   # InputHelper (console I/O), DataSeeder (sample data)
```

Data is in-memory only (no persistence) — this is expected for Sprint 1. Sprint 2 rebuilds this as a Spring Boot + Angular app with JDBC/SQL persistence.
