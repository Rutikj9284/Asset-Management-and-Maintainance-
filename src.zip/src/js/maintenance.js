/* =========================================================
   MAINTENANCE.JS
   Renders the maintenance log (visible to everyone) and owns
   the "Log Maintenance" modal, which is Admin-only.
   ========================================================= */

function populateAssetSelect(){
  const select = $("#l-asset");
  select.innerHTML = assets.map(a => `<option value="${a.id}">${a.tag} — ${a.name}</option>`).join("");
}

function renderMaintenanceTable(){
  const sorted = [...maintenanceLog].sort((a, b) => new Date(b.performed) - new Date(a.performed));
  const tbody = $("#maintenance-tbody");
  $("#maintenance-empty").hidden = sorted.length !== 0;
  tbody.innerHTML = sorted.map(m => {
    const asset = assets.find(a => a.id === m.assetId);
    return `
      <tr>
        <td>${asset ? `<span class="tag-chip">${asset.tag}</span> ${asset.name}` : "Unknown"}</td>
        <td>${m.type}</td>
        <td>${fmtDate(m.performed)}</td>
        <td>${fmtDate(m.nextDue)}</td>
        <td>${m.tech || "—"}</td>
        <td>${m.notes || "—"}</td>
      </tr>`;
  }).join("");
}

/* ---------- LOG MODAL ---------- */
const logModal = $("#log-modal");

function openLogModal(){
  if (!isAdmin()) return; // employees never reach the button, but guard anyway
  populateAssetSelect();
  $("#log-form").reset();
  $("#l-performed").value = new Date().toISOString().slice(0, 10);
  logModal.hidden = false;
}
function closeLogModal(){ logModal.hidden = true; }

$("#btn-add-log").addEventListener("click", openLogModal);
$("#log-modal-close").addEventListener("click", closeLogModal);
$("#log-modal-cancel").addEventListener("click", closeLogModal);
logModal.addEventListener("click", (e) => { if (e.target === logModal) closeLogModal(); });

$("#log-form").addEventListener("submit", (e) => {
  e.preventDefault();
  if (!isAdmin()) return;
  maintenanceLog.push({
    id: nextLogId++,
    assetId: Number($("#l-asset").value),
    type: $("#l-type").value,
    performed: $("#l-performed").value,
    nextDue: $("#l-next-due").value,
    tech: $("#l-tech").value.trim(),
    notes: $("#l-notes").value.trim(),
  });
  closeLogModal();
  showToast("Maintenance record saved");
  render();
});
