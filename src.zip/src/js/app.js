/* =========================================================
   ASSETTRAK — SPRINT 1 STATIC FRONTEND
   All data lives in memory (no backend yet). This exact
   data shape/behaviour is what gets rebuilt on Spring Boot
   + Angular + JPA in Sprint 2.
   ========================================================= */

/* ---------- SEED DATA ---------- */
let assets = [
  { id: 1, tag: "AT-1001", name: "HP LaserJet Pro M404", category: "IT Equipment", location: "Building A – Floor 2", purchaseDate: "2023-03-14", status: "Operational", notes: "Shared print station" },
  { id: 2, tag: "AT-1002", name: "Dell Latitude 5440", category: "IT Equipment", location: "Building A – Floor 3", purchaseDate: "2022-11-02", status: "Maintenance Due", notes: "Battery health low" },
  { id: 3, tag: "AT-1003", name: "Carrier Split AC 1.5T", category: "HVAC", location: "Building B – Floor 1", purchaseDate: "2021-06-20", status: "Under Repair", notes: "Compressor noise reported" },
  { id: 4, tag: "AT-1004", name: "Kirloskar Diesel Genset 62kVA", category: "Power", location: "Building B – Basement", purchaseDate: "2020-01-10", status: "Operational", notes: "Monthly load test" },
  { id: 5, tag: "AT-1005", name: "Godrej Fire Extinguisher CO2", category: "Safety", location: "Building A – Floor 1", purchaseDate: "2023-08-05", status: "Operational", notes: "" },
  { id: 6, tag: "AT-1006", name: "Herman Miller Aeron Chair", category: "Furniture", location: "Building A – Floor 2", purchaseDate: "2019-09-18", status: "Retired", notes: "Frame cracked" },
  { id: 7, tag: "AT-1007", name: "Cisco Catalyst 9300 Switch", category: "IT Equipment", location: "Building A – Server Room", purchaseDate: "2022-02-28", status: "Operational", notes: "Core network switch" },
  { id: 8, tag: "AT-1008", name: "Otis Passenger Elevator", category: "Facility", location: "Building B – Core", purchaseDate: "2018-05-01", status: "Maintenance Due", notes: "Annual inspection pending" },
];

let maintenanceLog = [
  { id: 1, assetId: 3, type: "Corrective", performed: "2026-06-20", nextDue: "2026-07-20", tech: "R. Sharma", notes: "Replaced compressor relay" },
  { id: 2, assetId: 4, type: "Preventive", performed: "2026-06-01", nextDue: "2026-07-01", tech: "P. Iyer", notes: "Monthly load test completed" },
  { id: 3, assetId: 8, type: "Inspection", performed: "2026-05-15", nextDue: "2026-07-10", tech: "External Vendor", notes: "Statutory annual inspection" },
  { id: 4, assetId: 2, type: "Preventive", performed: "2026-05-02", nextDue: "2026-07-05", tech: "S. Nair", notes: "Battery diagnostics run" },
];

let nextAssetId = 9;
let nextLogId = 5;

const STATUS_COLORS = {
  "Operational": "var(--teal)",
  "Maintenance Due": "var(--amber)",
  "Under Repair": "var(--rust)",
  "Retired": "var(--steel-soft)",
};

let currentView = "dashboard";
let activeStatusFilter = "all";
let activeCategoryFilter = "all";
let searchTerm = "";
let sortKey = "tag";
let sortDir = 1;

/* ---------- UTIL ---------- */
const $ = (sel, scope = document) => scope.querySelector(sel);
const $$ = (sel, scope = document) => [...scope.querySelectorAll(sel)];
const statusClass = (s) => "status-" + s.replace(/\s+/g, "-");
const fmtDate = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
};
const daysUntil = (iso) => {
  if (!iso) return Infinity;
  const today = new Date(); today.setHours(0,0,0,0);
  const target = new Date(iso + "T00:00:00");
  return Math.round((target - today) / 86400000);
};

function showToast(msg){
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("is-visible");
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => t.classList.remove("is-visible"), 2200);
}

/* ---------- VIEW SWITCHING ---------- */
const VIEW_META = {
  dashboard: { title: "Dashboard", sub: "Overview of your organization's assets" },
  assets: { title: "Assets", sub: "Browse, filter, and manage every tracked asset" },
  maintenance: { title: "Maintenance", sub: "Service history and upcoming schedules" },
  reports: { title: "Reports", sub: "Breakdown of your asset inventory" },
};

function switchView(view){
  currentView = view;
  $$(".view").forEach(v => v.hidden = true);
  $("#view-" + view).hidden = false;
  $$(".nav-item").forEach(b => b.classList.toggle("is-active", b.dataset.view === view));
  $("#view-title").textContent = VIEW_META[view].title;
  $("#view-subtitle").textContent = VIEW_META[view].sub;
  render();
}

/* ---------- RENDER: DASHBOARD ---------- */
function renderDashboard(){
  const total = assets.length;
  const active = assets.filter(a => a.status === "Operational").length;
  const due = assets.filter(a => a.status === "Maintenance Due").length;
  const critical = assets.filter(a => a.status === "Under Repair").length;

  $("#stat-total").textContent = total;
  $("#stat-active").textContent = active;
  $("#stat-due").textContent = due;
  $("#stat-critical").textContent = critical;

  // status breakdown
  const statuses = ["Operational", "Maintenance Due", "Under Repair", "Retired"];
  const breakdown = $("#status-breakdown");
  breakdown.innerHTML = statuses.map(s => {
    const count = assets.filter(a => a.status === s).length;
    const pct = total ? Math.round((count / total) * 100) : 0;
    return `
      <div class="status-row">
        <span class="label">${s}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${pct}%; background:${STATUS_COLORS[s]}"></div></div>
        <span class="count">${count}</span>
      </div>`;
  }).join("");

  // upcoming maintenance (sorted by next due, soonest first)
  const upcoming = [...maintenanceLog]
    .filter(m => m.nextDue)
    .sort((a, b) => new Date(a.nextDue) - new Date(b.nextDue))
    .slice(0, 5);
  const list = $("#upcoming-list");
  if (!upcoming.length){
    list.innerHTML = `<li class="empty">No upcoming maintenance scheduled.</li>`;
  } else {
    list.innerHTML = upcoming.map(m => {
      const asset = assets.find(a => a.id === m.assetId);
      const dLeft = daysUntil(m.nextDue);
      const color = dLeft < 0 ? "var(--rust)" : dLeft <= 7 ? "var(--amber)" : "var(--teal)";
      const dueText = dLeft < 0 ? `${Math.abs(dLeft)}d overdue` : dLeft === 0 ? "Due today" : `Due in ${dLeft}d`;
      return `
        <li>
          <span class="activity-dot" style="background:${color}"></span>
          <div>
            <div class="activity-main">${asset ? asset.name : "Unknown asset"}</div>
            <div class="activity-sub">${m.type} · ${dueText} · ${fmtDate(m.nextDue)}</div>
          </div>
        </li>`;
    }).join("");
  }

  // recently added assets (last 5 by id desc)
  const recent = [...assets].sort((a, b) => b.id - a.id).slice(0, 5);
  $("#recent-assets-table tbody").innerHTML = recent.map(a => `
    <tr>
      <td><span class="tag-chip">${a.tag}</span></td>
      <td>${a.name}</td>
      <td>${a.category}</td>
      <td>${a.location}</td>
      <td><span class="status-pill ${statusClass(a.status)}">${a.status}</span></td>
    </tr>`).join("");
}

/* ---------- RENDER: ASSETS TABLE ---------- */
function populateCategoryFilter(){
  const select = $("#category-filter");
  const categories = [...new Set(assets.map(a => a.category))].sort();
  const current = select.value || "all";
  select.innerHTML = `<option value="all">All categories</option>` +
    categories.map(c => `<option value="${c}">${c}</option>`).join("");
  select.value = categories.includes(current) ? current : "all";
}

function populateCategoryDatalist(){
  const categories = [...new Set(assets.map(a => a.category))].sort();
  $("#category-list").innerHTML = categories.map(c => `<option value="${c}">`).join("");
}

function getFilteredSortedAssets(){
  let list = assets.filter(a => {
    const matchesStatus = activeStatusFilter === "all" || a.status === activeStatusFilter;
    const matchesCategory = activeCategoryFilter === "all" || a.category === activeCategoryFilter;
    const haystack = `${a.tag} ${a.name} ${a.category} ${a.location}`.toLowerCase();
    const matchesSearch = !searchTerm || haystack.includes(searchTerm.toLowerCase());
    return matchesStatus && matchesCategory && matchesSearch;
  });
  list.sort((a, b) => {
    let va = a[sortKey], vb = b[sortKey];
    if (sortKey === "purchaseDate"){ va = new Date(va); vb = new Date(vb); }
    if (va < vb) return -1 * sortDir;
    if (va > vb) return 1 * sortDir;
    return 0;
  });
  return list;
}

function renderAssetsTable(){
  populateCategoryFilter();
  const list = getFilteredSortedAssets();
  const tbody = $("#assets-tbody");
  $("#assets-empty").hidden = list.length !== 0;
  tbody.innerHTML = list.map(a => `
    <tr>
      <td><span class="tag-chip">${a.tag}</span></td>
      <td>${a.name}</td>
      <td>${a.category}</td>
      <td>${a.location}</td>
      <td>${fmtDate(a.purchaseDate)}</td>
      <td><span class="status-pill ${statusClass(a.status)}">${a.status}</span></td>
      <td class="col-actions">
        <div class="row-actions">
          <button class="icon-btn" title="Edit" data-edit="${a.id}">✎</button>
          <button class="icon-btn danger" title="Delete" data-delete="${a.id}">🗑</button>
        </div>
      </td>
    </tr>`).join("");
}

/* ---------- RENDER: MAINTENANCE TABLE ---------- */
function populateAssetSelect(){
  const select = $("#l-asset");
  select.innerHTML = assets.map(a => `<option value="${a.id}">${a.tag} — ${a.name}</option>`).join("");
}

function renderMaintenanceTable(){
  const sorted = [...maintenanceLog].sort((a, b) => new Date(b.performed) - new Date(a.performed));
  const tbody = $("#maintenance-tbody");
  $("#maintenance-empty").hidden = sorted.length !== 0;
  tbody.innerHTML = sorted.map(m => {
    const asset = assets.find(a => a.id === m.assetId);
    return `
      <tr>
        <td>${asset ? `<span class="tag-chip">${asset.tag}</span> ${asset.name}` : "Unknown"}</td>
        <td>${m.type}</td>
        <td>${fmtDate(m.performed)}</td>
        <td>${fmtDate(m.nextDue)}</td>
        <td>${m.tech || "—"}</td>
        <td>${m.notes || "—"}</td>
      </tr>`;
  }).join("");
}

/* ---------- RENDER: REPORTS ---------- */
function renderBarGroup(container, groupFn){
  const groups = {};
  assets.forEach(a => { const k = groupFn(a); groups[k] = (groups[k] || 0) + 1; });
  const max = Math.max(...Object.values(groups), 1);
  const palette = ["var(--teal)", "var(--amber)", "var(--rust)", "#5B7DB1", "#8E6FBE", "#4C9CB5"];
  container.innerHTML = Object.entries(groups).sort((a,b) => b[1]-a[1]).map(([label, count], i) => `
    <div class="status-row">
      <span class="label">${label}</span>
      <div class="bar-track"><div class="bar-fill" style="width:${(count/max)*100}%; background:${palette[i % palette.length]}"></div></div>
      <span class="count">${count}</span>
    </div>`).join("");
}

function renderReports(){
  renderBarGroup($("#report-category"), a => a.category);
  renderBarGroup($("#report-location"), a => a.location);
}

/* ---------- MASTER RENDER ---------- */
function render(){
  if (currentView === "dashboard") renderDashboard();
  if (currentView === "assets") renderAssetsTable();
  if (currentView === "maintenance") renderMaintenanceTable();
  if (currentView === "reports") renderReports();
}

/* ---------- ASSET MODAL ---------- */
const assetModal = $("#asset-modal");
function openAssetModal(asset = null){
  populateCategoryDatalist();
  $("#asset-form").reset();
  if (asset){
    $("#asset-modal-title").textContent = "Edit Asset";
    $("#asset-modal-submit").textContent = "Save Changes";
    $("#asset-id").value = asset.id;
    $("#f-tag").value = asset.tag;
    $("#f-name").value = asset.name;
    $("#f-category").value = asset.category;
    $("#f-location").value = asset.location;
    $("#f-purchase-date").value = asset.purchaseDate;
    $("#f-status").value = asset.status;
    $("#f-notes").value = asset.notes || "";
  } else {
    $("#asset-modal-title").textContent = "Add Asset";
    $("#asset-modal-submit").textContent = "Save Asset";
    $("#asset-id").value = "";
    $("#f-tag").value = `AT-${1000 + nextAssetId}`;
    $("#f-purchase-date").value = new Date().toISOString().slice(0,10);
  }
  assetModal.hidden = false;
  $("#f-tag").focus();
}
function closeAssetModal(){ assetModal.hidden = true; }

$("#btn-add-asset").addEventListener("click", () => openAssetModal());
$("#asset-modal-close").addEventListener("click", closeAssetModal);
$("#asset-modal-cancel").addEventListener("click", closeAssetModal);
assetModal.addEventListener("click", (e) => { if (e.target === assetModal) closeAssetModal(); });

$("#asset-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const id = $("#asset-id").value;
  const payload = {
    tag: $("#f-tag").value.trim(),
    name: $("#f-name").value.trim(),
    category: $("#f-category").value.trim(),
    location: $("#f-location").value.trim(),
    purchaseDate: $("#f-purchase-date").value,
    status: $("#f-status").value,
    notes: $("#f-notes").value.trim(),
  };
  if (id){
    const asset = assets.find(a => a.id === Number(id));
    Object.assign(asset, payload);
    showToast("Asset updated");
  } else {
    assets.push({ id: nextAssetId++, ...payload });
    showToast("Asset added");
  }
  closeAssetModal();
  render();
});

/* ---------- LOG MODAL ---------- */
const logModal = $("#log-modal");
function openLogModal(){
  populateAssetSelect();
  $("#log-form").reset();
  $("#l-performed").value = new Date().toISOString().slice(0,10);
  logModal.hidden = false;
}
function closeLogModal(){ logModal.hidden = true; }

$("#btn-add-log").addEventListener("click", openLogModal);
$("#log-modal-close").addEventListener("click", closeLogModal);
$("#log-modal-cancel").addEventListener("click", closeLogModal);
logModal.addEventListener("click", (e) => { if (e.target === logModal) closeLogModal(); });

$("#log-form").addEventListener("submit", (e) => {
  e.preventDefault();
  maintenanceLog.push({
    id: nextLogId++,
    assetId: Number($("#l-asset").value),
    type: $("#l-type").value,
    performed: $("#l-performed").value,
    nextDue: $("#l-next-due").value,
    tech: $("#l-tech").value.trim(),
    notes: $("#l-notes").value.trim(),
  });
  closeLogModal();
  showToast("Maintenance record saved");
  render();
});

/* ---------- TABLE ROW ACTIONS (delegated) ---------- */
$("#assets-tbody").addEventListener("click", (e) => {
  const editId = e.target.closest("[data-edit]")?.dataset.edit;
  const delId = e.target.closest("[data-delete]")?.dataset.delete;
  if (editId){
    openAssetModal(assets.find(a => a.id === Number(editId)));
  } else if (delId){
    const asset = assets.find(a => a.id === Number(delId));
    if (confirm(`Delete "${asset.name}" (${asset.tag})? This cannot be undone.`)){
      assets = assets.filter(a => a.id !== Number(delId));
      maintenanceLog = maintenanceLog.filter(m => m.assetId !== Number(delId));
      showToast("Asset deleted");
      render();
    }
  }
});

/* ---------- NAV ---------- */
$$(".nav-item").forEach(btn => btn.addEventListener("click", () => switchView(btn.dataset.view)));
$$("[data-view-link]").forEach(btn => btn.addEventListener("click", () => switchView(btn.dataset.viewLink)));

/* ---------- FILTERS / SEARCH / SORT ---------- */
$("#status-filters").addEventListener("click", (e) => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  activeStatusFilter = chip.dataset.status;
  $$(".chip").forEach(c => c.classList.toggle("is-active", c === chip));
  renderAssetsTable();
});
$("#category-filter").addEventListener("change", (e) => {
  activeCategoryFilter = e.target.value;
  renderAssetsTable();
});
$("#global-search").addEventListener("input", (e) => {
  searchTerm = e.target.value;
  if (currentView !== "assets") switchView("assets");
  else renderAssetsTable();
});
$("#assets-table thead").addEventListener("click", (e) => {
  const th = e.target.closest("[data-sort]");
  if (!th) return;
  const key = th.dataset.sort;
  if (sortKey === key) sortDir *= -1; else { sortKey = key; sortDir = 1; }
  renderAssetsTable();
});

/* ---------- ESC to close modals ---------- */
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape"){ closeAssetModal(); closeLogModal(); }
});

/* ---------- INIT ---------- */
switchView("dashboard");
