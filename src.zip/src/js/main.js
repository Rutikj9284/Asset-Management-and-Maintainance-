/* =========================================================
   MAIN.JS
   Last file loaded. Ties every module together:
     - the master render() dispatcher, called by every module
       whenever state changes
     - global keyboard shortcuts
     - the initial boot of the app
   ========================================================= */

function render(){
  if (currentView === "dashboard") renderDashboard();
  if (currentView === "assets") renderAssetsTable();
  if (currentView === "maintenance") renderMaintenanceTable();
  if (currentView === "reports") renderReports();
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape"){ closeAssetModal(); closeLogModal(); }
});

/* ---------- BOOT ---------- */
applyRoleVisibility();   // reflect the default role (Admin) before first paint
switchView("dashboard");
