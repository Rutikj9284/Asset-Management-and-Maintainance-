/* =========================================================
   NAV.JS
   Handles switching between the four "pages" of the app.
   There's no real routing in Sprint 1 (no URL changes) —
   it's just show/hide of the matching <section class="view">.
   Sprint 2's Angular Router will replace this file entirely.
   ========================================================= */

function switchView(view){
  currentView = view;
  $$(".view").forEach(v => v.hidden = true);
  $("#view-" + view).hidden = false;
  $$(".nav-item").forEach(b => b.classList.toggle("is-active", b.dataset.view === view));
  $("#view-title").textContent = VIEW_META[view].title;
  $("#view-subtitle").textContent = VIEW_META[view].sub;
  render();
}

$$(".nav-item").forEach(btn => btn.addEventListener("click", () => switchView(btn.dataset.view)));
$$("[data-view-link]").forEach(btn => btn.addEventListener("click", () => switchView(btn.dataset.viewLink)));
