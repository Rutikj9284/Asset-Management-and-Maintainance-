/* =========================================================
   ASSETS.JS
   Renders the Assets table (visible to everyone) and owns
   the Add/Edit Asset modal (Admin only — the button and the
   row-level edit/delete icons are hidden for Employees via
   applyRoleVisibility(), and the handlers below double-check
   isAdmin() as a second guard).
   ========================================================= */

function populateCategoryFilter(){
  const select = $("#category-filter");
  const categories = [...new Set(assets.map(a => a.category))].sort();
  const current = select.value || "all";
  select.innerHTML = `<option value="all">All categories</option>` +
    categories.map(c => `<option value="${c}">${c}</option>`).join("");
  select.value = categories.includes(current) ? current : "all";
}

function populateCategoryDatalist(){
  const categories = [...new Set(assets.map(a => a.category))].sort();
  $("#category-list").innerHTML = categories.map(c => `<option value="${c}">`).join("");
}

function getFilteredSortedAssets(){
  let list = assets.filter(a => {
    const matchesStatus = activeStatusFilter === "all" || a.status === activeStatusFilter;
    const matchesCategory = activeCategoryFilter === "all" || a.category === activeCategoryFilter;
    const haystack = `${a.tag} ${a.name} ${a.category} ${a.location}`.toLowerCase();
    const matchesSearch = !searchTerm || haystack.includes(searchTerm.toLowerCase());
    return matchesStatus && matchesCategory && matchesSearch;
  });
  list.sort((a, b) => {
    let va = a[sortKey], vb = b[sortKey];
    if (sortKey === "purchaseDate"){ va = new Date(va); vb = new Date(vb); }
    if (va < vb) return -1 * sortDir;
    if (va > vb) return 1 * sortDir;
    return 0;
  });
  return list;
}

function renderAssetsTable(){
  populateCategoryFilter();
  const list = getFilteredSortedAssets();
  const tbody = $("#assets-tbody");
  $("#assets-empty").hidden = list.length !== 0;
  const admin = isAdmin();

  tbody.innerHTML = list.map(a => `
    <tr>
      <td><span class="tag-chip">${a.tag}</span></td>
      <td>${a.name}</td>
      <td>${a.category}</td>
      <td>${a.location}</td>
      <td>${fmtDate(a.purchaseDate)}</td>
      <td><span class="status-pill ${statusClass(a.status)}">${a.status}</span></td>
      ${admin ? `
      <td class="col-actions">
        <div class="row-actions">
          <button class="icon-btn" title="Edit" data-edit="${a.id}">✎</button>
          <button class="icon-btn danger" title="Delete" data-delete="${a.id}">🗑</button>
        </div>
      </td>` : ``}
    </tr>`).join("");
}

/* ---------- ADD / EDIT MODAL ---------- */
const assetModal = $("#asset-modal");

function openAssetModal(asset = null){
  if (!isAdmin()) return; // employees never reach the button, but guard anyway
  populateCategoryDatalist();
  $("#asset-form").reset();
  if (asset){
    $("#asset-modal-title").textContent = "Edit Asset";
    $("#asset-modal-submit").textContent = "Save Changes";
    $("#asset-id").value = asset.id;
    $("#f-tag").value = asset.tag;
    $("#f-name").value = asset.name;
    $("#f-category").value = asset.category;
    $("#f-location").value = asset.location;
    $("#f-purchase-date").value = asset.purchaseDate;
    $("#f-status").value = asset.status;
    $("#f-notes").value = asset.notes || "";
  } else {
    $("#asset-modal-title").textContent = "Add Asset";
    $("#asset-modal-submit").textContent = "Save Asset";
    $("#asset-id").value = "";
    $("#f-tag").value = `AT-${1000 + nextAssetId}`;
    $("#f-purchase-date").value = new Date().toISOString().slice(0, 10);
  }
  assetModal.hidden = false;
  $("#f-tag").focus();
}
function closeAssetModal(){ assetModal.hidden = true; }

$("#btn-add-asset").addEventListener("click", () => openAssetModal());
$("#asset-modal-close").addEventListener("click", closeAssetModal);
$("#asset-modal-cancel").addEventListener("click", closeAssetModal);
assetModal.addEventListener("click", (e) => { if (e.target === assetModal) closeAssetModal(); });

$("#asset-form").addEventListener("submit", (e) => {
  e.preventDefault();
  if (!isAdmin()) return;
  const id = $("#asset-id").value;
  const payload = {
    tag: $("#f-tag").value.trim(),
    name: $("#f-name").value.trim(),
    category: $("#f-category").value.trim(),
    location: $("#f-location").value.trim(),
    purchaseDate: $("#f-purchase-date").value,
    status: $("#f-status").value,
    notes: $("#f-notes").value.trim(),
  };
  if (id){
    const asset = assets.find(a => a.id === Number(id));
    Object.assign(asset, payload);
    showToast("Asset updated");
  } else {
    assets.push({ id: nextAssetId++, ...payload });
    showToast("Asset added");
  }
  closeAssetModal();
  render();
});

/* ---------- ROW ACTIONS (delegated) ---------- */
$("#assets-tbody").addEventListener("click", (e) => {
  if (!isAdmin()) return;
  const editId = e.target.closest("[data-edit]")?.dataset.edit;
  const delId = e.target.closest("[data-delete]")?.dataset.delete;
  if (editId){
    openAssetModal(assets.find(a => a.id === Number(editId)));
  } else if (delId){
    const asset = assets.find(a => a.id === Number(delId));
    if (confirm(`Delete "${asset.name}" (${asset.tag})? This cannot be undone.`)){
      assets = assets.filter(a => a.id !== Number(delId));
      maintenanceLog = maintenanceLog.filter(m => m.assetId !== Number(delId));
      showToast("Asset deleted");
      render();
    }
  }
});

/* ---------- FILTERS / SEARCH / SORT ---------- */
$("#status-filters").addEventListener("click", (e) => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  activeStatusFilter = chip.dataset.status;
  $$(".chip").forEach(c => c.classList.toggle("is-active", c === chip));
  renderAssetsTable();
});
$("#category-filter").addEventListener("change", (e) => {
  activeCategoryFilter = e.target.value;
  renderAssetsTable();
});
$("#global-search").addEventListener("input", (e) => {
  searchTerm = e.target.value;
  if (currentView !== "assets") switchView("assets");
  else renderAssetsTable();
});
$("#assets-table thead").addEventListener("click", (e) => {
  const th = e.target.closest("[data-sort]");
  if (!th) return;
  const key = th.dataset.sort;
  if (sortKey === key) sortDir *= -1; else { sortKey = key; sortDir = 1; }
  renderAssetsTable();
});
