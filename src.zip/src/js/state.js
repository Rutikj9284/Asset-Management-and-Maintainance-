/* =========================================================
   STATE.JS
   All "what is the UI currently doing" state lives here —
   separate from data.js (which holds the actual records).
   Every other module reads/writes these shared variables.
   ========================================================= */

let currentView = "dashboard";
let currentRole = "Admin";          // "Admin" | "Employee" — see auth.js

let activeStatusFilter = "all";
let activeCategoryFilter = "all";
let searchTerm = "";
let sortKey = "tag";
let sortDir = 1;

const VIEW_META = {
  dashboard:   { title: "Dashboard",   sub: "Overview of your organization's assets" },
  assets:      { title: "Assets",      sub: "Browse, filter, and manage every tracked asset" },
  maintenance: { title: "Maintenance", sub: "Service history and upcoming schedules" },
  reports:     { title: "Reports",     sub: "Breakdown of your asset inventory" },
};
