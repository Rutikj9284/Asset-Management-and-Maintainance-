/* =========================================================
   UTILS.JS
   Small, generic helpers with no knowledge of assets or
   roles. Kept separate so every other module can rely on
   them without pulling in unrelated logic.
   ========================================================= */

const $ = (sel, scope = document) => scope.querySelector(sel);
const $$ = (sel, scope = document) => [...scope.querySelectorAll(sel)];

const statusClass = (s) => "status-" + s.replace(/\s+/g, "-");

const fmtDate = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
};

const daysUntil = (iso) => {
  if (!iso) return Infinity;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const target = new Date(iso + "T00:00:00");
  return Math.round((target - today) / 86400000);
};

function showToast(msg){
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("is-visible");
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => t.classList.remove("is-visible"), 2200);
}
