/* =========================================================
   AUTH.JS
   Sprint 1 has no real backend, so there's no login here —
   just a role switcher that simulates "who is logged in".
   In Sprint 2, Spring Security + JWT will replace this with
   a real login, and the role will come from the authenticated
   user's token instead of a dropdown.

   Permission rule for this app:
     - Admin    → full access (view + add/edit/delete assets,
                  log maintenance)
     - Employee → view-only (assets, maintenance log, reports)
   ========================================================= */

function isAdmin(){
  return currentRole === "Admin";
}

/** Show/hide every element flagged as admin-only or employee-only,
 *  and refresh the badges that display the current role. */
function applyRoleVisibility(){
  const admin = isAdmin();

  $$(".role-admin-only").forEach(el => { el.hidden = !admin; });
  $$(".role-employee-only").forEach(el => { el.hidden = admin; });

  const badge = $("#role-badge");
  badge.textContent = currentRole;
  badge.classList.toggle("is-employee", !admin);

  $("#user-role-label").textContent = admin ? "Admin" : "Employee";
}

function setRole(role){
  currentRole = role;
  applyRoleVisibility();
  render(); // re-render current view so tables/actions reflect the new role
}

$("#role-select").addEventListener("change", (e) => setRole(e.target.value));
