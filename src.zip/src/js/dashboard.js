/* =========================================================
   DASHBOARD.JS
   Renders the Dashboard view. Read-only for every role —
   Admin and Employee see exactly the same dashboard.
   ========================================================= */

function renderDashboard(){
  const total = assets.length;
  const active = assets.filter(a => a.status === "Operational").length;
  const due = assets.filter(a => a.status === "Maintenance Due").length;
  const critical = assets.filter(a => a.status === "Under Repair").length;

  $("#stat-total").textContent = total;
  $("#stat-active").textContent = active;
  $("#stat-due").textContent = due;
  $("#stat-critical").textContent = critical;

  // status breakdown
  const statuses = ["Operational", "Maintenance Due", "Under Repair", "Retired"];
  const breakdown = $("#status-breakdown");
  breakdown.innerHTML = statuses.map(s => {
    const count = assets.filter(a => a.status === s).length;
    const pct = total ? Math.round((count / total) * 100) : 0;
    return `
      <div class="status-row">
        <span class="label">${s}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${pct}%; background:${STATUS_COLORS[s]}"></div></div>
        <span class="count">${count}</span>
      </div>`;
  }).join("");

  // upcoming maintenance (sorted by next due, soonest first)
  const upcoming = [...maintenanceLog]
    .filter(m => m.nextDue)
    .sort((a, b) => new Date(a.nextDue) - new Date(b.nextDue))
    .slice(0, 5);
  const list = $("#upcoming-list");
  if (!upcoming.length){
    list.innerHTML = `<li class="empty">No upcoming maintenance scheduled.</li>`;
  } else {
    list.innerHTML = upcoming.map(m => {
      const asset = assets.find(a => a.id === m.assetId);
      const dLeft = daysUntil(m.nextDue);
      const color = dLeft < 0 ? "var(--rust)" : dLeft <= 7 ? "var(--amber)" : "var(--teal)";
      const dueText = dLeft < 0 ? `${Math.abs(dLeft)}d overdue` : dLeft === 0 ? "Due today" : `Due in ${dLeft}d`;
      return `
        <li>
          <span class="activity-dot" style="background:${color}"></span>
          <div>
            <div class="activity-main">${asset ? asset.name : "Unknown asset"}</div>
            <div class="activity-sub">${m.type} · ${dueText} · ${fmtDate(m.nextDue)}</div>
          </div>
        </li>`;
    }).join("");
  }

  // recently added assets (last 5 by id desc)
  const recent = [...assets].sort((a, b) => b.id - a.id).slice(0, 5);
  $("#recent-assets-table tbody").innerHTML = recent.map(a => `
    <tr>
      <td><span class="tag-chip">${a.tag}</span></td>
      <td>${a.name}</td>
      <td>${a.category}</td>
      <td>${a.location}</td>
      <td><span class="status-pill ${statusClass(a.status)}">${a.status}</span></td>
    </tr>`).join("");
}
