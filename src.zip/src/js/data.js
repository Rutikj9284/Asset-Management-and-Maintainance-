/* =========================================================
   DATA.JS
   The in-memory "database" for Sprint 1. In Sprint 2 this
   file disappears — assets/maintenanceLog will instead come
   from HTTP calls to the Spring Boot API (via an Angular
   AssetService / MaintenanceService), but the shape of each
   object below is exactly what those API responses should
   look like.
   ========================================================= */

let assets = [
  { id: 1, tag: "AT-1001", name: "HP LaserJet Pro M404", category: "IT Equipment", location: "Building A – Floor 2", purchaseDate: "2023-03-14", status: "Operational", notes: "Shared print station" },
  { id: 2, tag: "AT-1002", name: "Dell Latitude 5440", category: "IT Equipment", location: "Building A – Floor 3", purchaseDate: "2022-11-02", status: "Maintenance Due", notes: "Battery health low" },
  { id: 3, tag: "AT-1003", name: "Carrier Split AC 1.5T", category: "HVAC", location: "Building B – Floor 1", purchaseDate: "2021-06-20", status: "Under Repair", notes: "Compressor noise reported" },
  { id: 4, tag: "AT-1004", name: "Kirloskar Diesel Genset 62kVA", category: "Power", location: "Building B – Basement", purchaseDate: "2020-01-10", status: "Operational", notes: "Monthly load test" },
  { id: 5, tag: "AT-1005", name: "Godrej Fire Extinguisher CO2", category: "Safety", location: "Building A – Floor 1", purchaseDate: "2023-08-05", status: "Operational", notes: "" },
  { id: 6, tag: "AT-1006", name: "Herman Miller Aeron Chair", category: "Furniture", location: "Building A – Floor 2", purchaseDate: "2019-09-18", status: "Retired", notes: "Frame cracked" },
  { id: 7, tag: "AT-1007", name: "Cisco Catalyst 9300 Switch", category: "IT Equipment", location: "Building A – Server Room", purchaseDate: "2022-02-28", status: "Operational", notes: "Core network switch" },
  { id: 8, tag: "AT-1008", name: "Otis Passenger Elevator", category: "Facility", location: "Building B – Core", purchaseDate: "2018-05-01", status: "Maintenance Due", notes: "Annual inspection pending" },
];

let maintenanceLog = [
  { id: 1, assetId: 3, type: "Corrective", performed: "2026-06-20", nextDue: "2026-07-20", tech: "R. Sharma", notes: "Replaced compressor relay" },
  { id: 2, assetId: 4, type: "Preventive", performed: "2026-06-01", nextDue: "2026-07-01", tech: "P. Iyer", notes: "Monthly load test completed" },
  { id: 3, assetId: 8, type: "Inspection", performed: "2026-05-15", nextDue: "2026-07-10", tech: "External Vendor", notes: "Statutory annual inspection" },
  { id: 4, assetId: 2, type: "Preventive", performed: "2026-05-02", nextDue: "2026-07-05", tech: "S. Nair", notes: "Battery diagnostics run" },
];

let nextAssetId = 9;
let nextLogId = 5;

const STATUS_COLORS = {
  "Operational": "var(--teal)",
  "Maintenance Due": "var(--amber)",
  "Under Repair": "var(--rust)",
  "Retired": "var(--steel-soft)",
};
