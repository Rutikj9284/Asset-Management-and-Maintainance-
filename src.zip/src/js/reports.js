/* =========================================================
   REPORTS.JS
   Renders the Reports view. Read-only for every role.
   ========================================================= */

function renderBarGroup(container, groupFn){
  const groups = {};
  assets.forEach(a => { const k = groupFn(a); groups[k] = (groups[k] || 0) + 1; });
  const max = Math.max(...Object.values(groups), 1);
  const palette = ["var(--teal)", "var(--amber)", "var(--rust)", "#5B7DB1", "#8E6FBE", "#4C9CB5"];
  container.innerHTML = Object.entries(groups).sort((a, b) => b[1] - a[1]).map(([label, count], i) => `
    <div class="status-row">
      <span class="label">${label}</span>
      <div class="bar-track"><div class="bar-fill" style="width:${(count / max) * 100}%; background:${palette[i % palette.length]}"></div></div>
      <span class="count">${count}</span>
    </div>`).join("");
}

function renderReports(){
  renderBarGroup($("#report-category"), a => a.category);
  renderBarGroup($("#report-location"), a => a.location);
}
