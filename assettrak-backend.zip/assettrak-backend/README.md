# AssetTrak — Sprint 2 Backend (Spring Boot + H2)

## Stack
- Java 17, Spring Boot 3.2.5
- Spring Web, Spring Data JPA, Spring Security
- H2 in-memory database
- JWT authentication (jjwt)

## Run
```
mvn spring-boot:run
```
The API starts on `http://localhost:8080`.

H2 console: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:assettrak`
- User: `sa`, no password

## Seeded demo accounts
| Role  | Username | Password   |
|-------|----------|------------|
| Admin | admin    | Admin@123  |
| User  | jdoe     | User@123   |

Registering a new account via `/api/auth/register` always creates a **USER**-role
account (and a matching Employee profile). Only the seeded `admin` account has
ADMIN privileges in this demo.

## Key endpoints
- `POST /api/auth/register` — create account (validated)
- `POST /api/auth/login` — returns JWT
- `GET/POST/PUT/DELETE /api/assets` — admin only (paginated: `?page=&size=&search=&status=`)
- `PATCH /api/assets/{id}/assign` — admin assigns/unassigns an asset
- `GET /api/assets/my-assets` — current user's assigned assets (paginated)
- `GET/POST/PUT/DELETE /api/employees` — admin only (paginated: `?page=&size=&search=`)
- `GET /api/requests` — admin only, all maintenance requests (paginated, `?status=`)
- `GET /api/requests/my-requests` — current user's own requests (paginated)
- `POST /api/requests` — user raises a maintenance request
- `PATCH /api/requests/{id}/approve` / `/reject` — admin decision

All endpoints except `/api/auth/**` require `Authorization: Bearer <token>`.
