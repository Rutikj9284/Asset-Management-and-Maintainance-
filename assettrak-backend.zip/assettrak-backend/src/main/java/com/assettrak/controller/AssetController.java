package com.assettrak.controller;

import com.assettrak.dto.AssetDto;
import com.assettrak.dto.AssignAssetRequest;
import com.assettrak.dto.PageResponse;
import com.assettrak.model.AssetStatus;
import com.assettrak.model.Employee;
import com.assettrak.service.AssetService;
import com.assettrak.service.CurrentUserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/assets")
@RequiredArgsConstructor
public class AssetController {

    private final AssetService assetService;
    private final CurrentUserService currentUserService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PageResponse<AssetDto>> list(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) AssetStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return ResponseEntity.ok(PageResponse.of(assetService.list(search, status, pageable)));
    }

    @GetMapping("/my-assets")
    public ResponseEntity<PageResponse<AssetDto>> myAssets(
            Authentication authentication,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Employee employee = currentUserService.getEmployee(authentication);
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return ResponseEntity.ok(PageResponse.of(assetService.listAssignedTo(employee.getId(), pageable)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<AssetDto> get(@PathVariable Long id) {
        return ResponseEntity.ok(assetService.get(id));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AssetDto> create(@Valid @RequestBody AssetDto dto) {
        return ResponseEntity.ok(assetService.create(dto));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AssetDto> update(@PathVariable Long id, @Valid @RequestBody AssetDto dto) {
        return ResponseEntity.ok(assetService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        assetService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AssetDto> assign(@PathVariable Long id, @RequestBody AssignAssetRequest request) {
        return ResponseEntity.ok(assetService.assign(id, request.getEmployeeId()));
    }
}
