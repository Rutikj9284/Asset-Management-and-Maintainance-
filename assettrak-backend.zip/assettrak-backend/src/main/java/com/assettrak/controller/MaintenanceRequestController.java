package com.assettrak.controller;

import com.assettrak.dto.MaintenanceRequestDto;
import com.assettrak.dto.PageResponse;
import com.assettrak.dto.RequestDecisionDto;
import com.assettrak.model.Employee;
import com.assettrak.model.RequestStatus;
import com.assettrak.service.CurrentUserService;
import com.assettrak.service.MaintenanceRequestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/requests")
@RequiredArgsConstructor
public class MaintenanceRequestController {

    private final MaintenanceRequestService requestService;
    private final CurrentUserService currentUserService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PageResponse<MaintenanceRequestDto>> list(
            @RequestParam(required = false) RequestStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return ResponseEntity.ok(PageResponse.of(requestService.list(status, pageable)));
    }

    @GetMapping("/my-requests")
    public ResponseEntity<PageResponse<MaintenanceRequestDto>> myRequests(
            Authentication authentication,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Employee employee = currentUserService.getEmployee(authentication);
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return ResponseEntity.ok(PageResponse.of(requestService.listForEmployee(employee.getId(), pageable)));
    }

    @PostMapping
    public ResponseEntity<MaintenanceRequestDto> create(
            Authentication authentication,
            @Valid @RequestBody MaintenanceRequestDto dto) {
        Employee employee = currentUserService.getEmployee(authentication);
        return ResponseEntity.ok(requestService.create(employee.getId(), dto));
    }

    @PatchMapping("/{id}/approve")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<MaintenanceRequestDto> approve(@PathVariable Long id, @RequestBody(required = false) RequestDecisionDto decision) {
        String remarks = decision != null ? decision.getAdminRemarks() : null;
        return ResponseEntity.ok(requestService.decide(id, RequestStatus.APPROVED, remarks));
    }

    @PatchMapping("/{id}/reject")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<MaintenanceRequestDto> reject(@PathVariable Long id, @RequestBody(required = false) RequestDecisionDto decision) {
        String remarks = decision != null ? decision.getAdminRemarks() : null;
        return ResponseEntity.ok(requestService.decide(id, RequestStatus.REJECTED, remarks));
    }
}
