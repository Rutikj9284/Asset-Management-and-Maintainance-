package com.assettrak.model;

public enum Role {
    ADMIN,
    USER
}
