package com.assettrak.model;

public enum AssetStatus {
    AVAILABLE,
    ASSIGNED,
    IN_MAINTENANCE,
    RETIRED
}
