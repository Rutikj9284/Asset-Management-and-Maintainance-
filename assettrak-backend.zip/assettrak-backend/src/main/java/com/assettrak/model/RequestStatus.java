package com.assettrak.model;

public enum RequestStatus {
    PENDING,
    APPROVED,
    REJECTED,
    COMPLETED
}
