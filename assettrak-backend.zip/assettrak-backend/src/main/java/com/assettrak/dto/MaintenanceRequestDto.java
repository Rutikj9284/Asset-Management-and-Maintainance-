package com.assettrak.dto;

import com.assettrak.model.RequestStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class MaintenanceRequestDto {
    private Long id;

    @NotNull(message = "Asset is required")
    private Long assetId;

    private String assetName;
    private String assetSerialNumber;

    private Long requestedByEmployeeId;
    private String requestedByEmployeeName;

    @NotBlank(message = "Description is required")
    private String description;

    private RequestStatus status;
    private LocalDateTime requestDate;
    private LocalDateTime resolvedDate;
    private String adminRemarks;
}
