package com.assettrak.dto;

import com.assettrak.model.AssetStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class AssetDto {
    private Long id;

    @NotBlank(message = "Asset name is required")
    private String name;

    @NotBlank(message = "Asset type is required")
    private String type;

    @NotBlank(message = "Serial number is required")
    private String serialNumber;

    private AssetStatus status;

    private LocalDate purchaseDate;

    private String location;

    private Long assignedToEmployeeId;
    private String assignedToEmployeeName;
}
