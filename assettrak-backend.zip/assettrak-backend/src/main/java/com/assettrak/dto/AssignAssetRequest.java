package com.assettrak.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AssignAssetRequest {
    private Long employeeId;
}
