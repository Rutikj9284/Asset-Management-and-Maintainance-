package com.assettrak.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequestDecisionDto {
    private String adminRemarks;
}
