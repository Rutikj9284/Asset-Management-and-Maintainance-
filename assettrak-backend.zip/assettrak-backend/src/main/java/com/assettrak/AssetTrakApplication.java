package com.assettrak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssetTrakApplication {
    public static void main(String[] args) {
        SpringApplication.run(AssetTrakApplication.class, args);
    }
}
