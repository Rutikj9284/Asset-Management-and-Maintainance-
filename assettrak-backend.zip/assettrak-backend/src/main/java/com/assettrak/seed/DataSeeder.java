package com.assettrak.seed;

import com.assettrak.model.*;
import com.assettrak.repository.AssetRepository;
import com.assettrak.repository.EmployeeRepository;
import com.assettrak.repository.MaintenanceRequestRepository;
import com.assettrak.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final EmployeeRepository employeeRepository;
    private final AssetRepository assetRepository;
    private final MaintenanceRequestRepository requestRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            return;
        }

        // Admin user (no employee profile needed for admin)
        User admin = new User();
        admin.setUsername("admin");
        admin.setEmail("admin@assettrak.com");
        admin.setFullName("System Administrator");
        admin.setPassword(passwordEncoder.encode("Admin@123"));
        admin.setRole(Role.ADMIN);
        userRepository.save(admin);

        // Demo employee user
        User demoUser = new User();
        demoUser.setUsername("jdoe");
        demoUser.setEmail("jdoe@assettrak.com");
        demoUser.setFullName("John Doe");
        demoUser.setPassword(passwordEncoder.encode("User@123"));
        demoUser.setRole(Role.USER);
        userRepository.save(demoUser);

        Employee johnEmployee = new Employee();
        johnEmployee.setName("John Doe");
        johnEmployee.setEmail("jdoe@assettrak.com");
        johnEmployee.setDepartment("Engineering");
        johnEmployee.setDesignation("Software Engineer");
        johnEmployee.setPhone("9876543210");
        johnEmployee.setUser(demoUser);
        employeeRepository.save(johnEmployee);

        Employee priyaEmployee = new Employee();
        priyaEmployee.setName("Priya Sharma");
        priyaEmployee.setEmail("priya.sharma@assettrak.com");
        priyaEmployee.setDepartment("Human Resources");
        priyaEmployee.setDesignation("HR Executive");
        priyaEmployee.setPhone("9876500000");
        employeeRepository.save(priyaEmployee);

        Asset laptop = new Asset();
        laptop.setName("Dell Latitude 5440");
        laptop.setType("Laptop");
        laptop.setSerialNumber("SN-LAP-1001");
        laptop.setStatus(AssetStatus.ASSIGNED);
        laptop.setPurchaseDate(LocalDate.of(2024, 3, 12));
        laptop.setLocation("Bangalore Office");
        laptop.setAssignedTo(johnEmployee);
        assetRepository.save(laptop);

        Asset monitor = new Asset();
        monitor.setName("Dell 24-inch Monitor");
        monitor.setType("Monitor");
        monitor.setSerialNumber("SN-MON-2001");
        monitor.setStatus(AssetStatus.AVAILABLE);
        monitor.setPurchaseDate(LocalDate.of(2023, 11, 5));
        monitor.setLocation("Bangalore Office");
        assetRepository.save(monitor);

        Asset chair = new Asset();
        chair.setName("Ergonomic Office Chair");
        chair.setType("Furniture");
        chair.setSerialNumber("SN-CHR-3001");
        chair.setStatus(AssetStatus.ASSIGNED);
        chair.setPurchaseDate(LocalDate.of(2023, 6, 20));
        chair.setLocation("Bangalore Office");
        chair.setAssignedTo(priyaEmployee);
        assetRepository.save(chair);

        Asset phone = new Asset();
        phone.setName("iPhone 14");
        phone.setType("Mobile Device");
        phone.setSerialNumber("SN-PHN-4001");
        phone.setStatus(AssetStatus.AVAILABLE);
        phone.setPurchaseDate(LocalDate.of(2024, 1, 15));
        phone.setLocation("Bangalore Office");
        assetRepository.save(phone);

        MaintenanceRequest request = new MaintenanceRequest();
        request.setAsset(laptop);
        request.setRequestedBy(johnEmployee);
        request.setDescription("Laptop battery draining very fast, needs inspection.");
        request.setStatus(RequestStatus.PENDING);
        requestRepository.save(request);
    }
}
