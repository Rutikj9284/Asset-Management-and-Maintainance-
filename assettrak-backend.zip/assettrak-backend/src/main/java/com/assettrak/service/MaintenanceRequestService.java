package com.assettrak.service;

import com.assettrak.dto.MaintenanceRequestDto;
import com.assettrak.exception.BadRequestException;
import com.assettrak.exception.ResourceNotFoundException;
import com.assettrak.model.Asset;
import com.assettrak.model.Employee;
import com.assettrak.model.MaintenanceRequest;
import com.assettrak.model.RequestStatus;
import com.assettrak.repository.AssetRepository;
import com.assettrak.repository.EmployeeRepository;
import com.assettrak.repository.MaintenanceRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class MaintenanceRequestService {

    private final MaintenanceRequestRepository requestRepository;
    private final AssetRepository assetRepository;
    private final EmployeeRepository employeeRepository;

    public Page<MaintenanceRequestDto> list(RequestStatus status, Pageable pageable) {
        Page<MaintenanceRequest> page = status != null
                ? requestRepository.findByStatus(status, pageable)
                : requestRepository.findAll(pageable);
        return page.map(this::toDto);
    }

    public Page<MaintenanceRequestDto> listForEmployee(Long employeeId, Pageable pageable) {
        return requestRepository.findByRequestedById(employeeId, pageable).map(this::toDto);
    }

    @Transactional
    public MaintenanceRequestDto create(Long employeeId, MaintenanceRequestDto dto) {
        Asset asset = assetRepository.findById(dto.getAssetId())
                .orElseThrow(() -> new ResourceNotFoundException("Asset not found with id: " + dto.getAssetId()));
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee profile not found"));

        MaintenanceRequest request = new MaintenanceRequest();
        request.setAsset(asset);
        request.setRequestedBy(employee);
        request.setDescription(dto.getDescription());
        request.setStatus(RequestStatus.PENDING);
        request.setRequestDate(LocalDateTime.now());

        return toDto(requestRepository.save(request));
    }

    @Transactional
    public MaintenanceRequestDto decide(Long requestId, RequestStatus decision, String remarks) {
        if (decision != RequestStatus.APPROVED && decision != RequestStatus.REJECTED) {
            throw new BadRequestException("Decision must be APPROVED or REJECTED");
        }
        MaintenanceRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Request not found with id: " + requestId));

        if (request.getStatus() != RequestStatus.PENDING) {
            throw new BadRequestException("Only pending requests can be approved or rejected");
        }

        request.setStatus(decision);
        request.setAdminRemarks(remarks);
        request.setResolvedDate(LocalDateTime.now());

        if (decision == RequestStatus.APPROVED) {
            Asset asset = request.getAsset();
            asset.setStatus(com.assettrak.model.AssetStatus.IN_MAINTENANCE);
            assetRepository.save(asset);
        }

        return toDto(requestRepository.save(request));
    }

    private MaintenanceRequestDto toDto(MaintenanceRequest r) {
        MaintenanceRequestDto dto = new MaintenanceRequestDto();
        dto.setId(r.getId());
        dto.setAssetId(r.getAsset().getId());
        dto.setAssetName(r.getAsset().getName());
        dto.setAssetSerialNumber(r.getAsset().getSerialNumber());
        dto.setRequestedByEmployeeId(r.getRequestedBy().getId());
        dto.setRequestedByEmployeeName(r.getRequestedBy().getName());
        dto.setDescription(r.getDescription());
        dto.setStatus(r.getStatus());
        dto.setRequestDate(r.getRequestDate());
        dto.setResolvedDate(r.getResolvedDate());
        dto.setAdminRemarks(r.getAdminRemarks());
        return dto;
    }
}
