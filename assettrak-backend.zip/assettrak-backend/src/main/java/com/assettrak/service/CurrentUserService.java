package com.assettrak.service;

import com.assettrak.exception.ResourceNotFoundException;
import com.assettrak.model.Employee;
import com.assettrak.model.User;
import com.assettrak.repository.EmployeeRepository;
import com.assettrak.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CurrentUserService {

    private final UserRepository userRepository;
    private final EmployeeRepository employeeRepository;

    public User getUser(Authentication authentication) {
        String username = authentication.getName();
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    public Employee getEmployee(Authentication authentication) {
        User user = getUser(authentication);
        return employeeRepository.findByUserId(user.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee profile not found for current user"));
    }
}
