package com.assettrak.service;

import com.assettrak.dto.AssetDto;
import com.assettrak.exception.BadRequestException;
import com.assettrak.exception.ResourceNotFoundException;
import com.assettrak.model.Asset;
import com.assettrak.model.AssetStatus;
import com.assettrak.model.Employee;
import com.assettrak.repository.AssetRepository;
import com.assettrak.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AssetService {

    private final AssetRepository assetRepository;
    private final EmployeeRepository employeeRepository;

    public Page<AssetDto> list(String search, AssetStatus status, Pageable pageable) {
        Page<Asset> page;
        if (status != null) {
            page = assetRepository.findByStatus(status, pageable);
        } else if (search != null && !search.isBlank()) {
            page = assetRepository.findByNameContainingIgnoreCaseOrSerialNumberContainingIgnoreCase(search, search, pageable);
        } else {
            page = assetRepository.findAll(pageable);
        }
        return page.map(this::toDto);
    }

    public Page<AssetDto> listAssignedTo(Long employeeId, Pageable pageable) {
        return assetRepository.findByAssignedToId(employeeId, pageable).map(this::toDto);
    }

    public AssetDto get(Long id) {
        return toDto(findEntity(id));
    }

    @Transactional
    public AssetDto create(AssetDto dto) {
        if (assetRepository.existsBySerialNumber(dto.getSerialNumber())) {
            throw new BadRequestException("An asset with this serial number already exists");
        }
        Asset asset = new Asset();
        applyDto(asset, dto);
        return toDto(assetRepository.save(asset));
    }

    @Transactional
    public AssetDto update(Long id, AssetDto dto) {
        Asset asset = findEntity(id);
        applyDto(asset, dto);
        return toDto(assetRepository.save(asset));
    }

    @Transactional
    public void delete(Long id) {
        Asset asset = findEntity(id);
        assetRepository.delete(asset);
    }

    @Transactional
    public AssetDto assign(Long assetId, Long employeeId) {
        Asset asset = findEntity(assetId);
        if (employeeId == null) {
            asset.setAssignedTo(null);
            asset.setStatus(AssetStatus.AVAILABLE);
        } else {
            Employee employee = employeeRepository.findById(employeeId)
                    .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + employeeId));
            asset.setAssignedTo(employee);
            asset.setStatus(AssetStatus.ASSIGNED);
        }
        return toDto(assetRepository.save(asset));
    }

    private Asset findEntity(Long id) {
        return assetRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Asset not found with id: " + id));
    }

    private void applyDto(Asset asset, AssetDto dto) {
        asset.setName(dto.getName());
        asset.setType(dto.getType());
        asset.setSerialNumber(dto.getSerialNumber());
        asset.setPurchaseDate(dto.getPurchaseDate());
        asset.setLocation(dto.getLocation());
        if (dto.getStatus() != null) {
            asset.setStatus(dto.getStatus());
        }
        if (dto.getAssignedToEmployeeId() != null) {
            Employee employee = employeeRepository.findById(dto.getAssignedToEmployeeId())
                    .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + dto.getAssignedToEmployeeId()));
            asset.setAssignedTo(employee);
        }
    }

    private AssetDto toDto(Asset a) {
        AssetDto dto = new AssetDto();
        dto.setId(a.getId());
        dto.setName(a.getName());
        dto.setType(a.getType());
        dto.setSerialNumber(a.getSerialNumber());
        dto.setStatus(a.getStatus());
        dto.setPurchaseDate(a.getPurchaseDate());
        dto.setLocation(a.getLocation());
        if (a.getAssignedTo() != null) {
            dto.setAssignedToEmployeeId(a.getAssignedTo().getId());
            dto.setAssignedToEmployeeName(a.getAssignedTo().getName());
        }
        return dto;
    }
}
