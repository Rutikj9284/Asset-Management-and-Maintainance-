package com.assettrak.service;

import com.assettrak.dto.EmployeeDto;
import com.assettrak.exception.BadRequestException;
import com.assettrak.exception.ResourceNotFoundException;
import com.assettrak.model.Employee;
import com.assettrak.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public Page<EmployeeDto> list(String search, Pageable pageable) {
        Page<Employee> page = (search == null || search.isBlank())
                ? employeeRepository.findAll(pageable)
                : employeeRepository.findByNameContainingIgnoreCase(search, pageable);
        return page.map(this::toDto);
    }

    public EmployeeDto get(Long id) {
        return toDto(findEntity(id));
    }

    @Transactional
    public EmployeeDto create(EmployeeDto dto) {
        if (employeeRepository.findByEmail(dto.getEmail()).isPresent()) {
            throw new BadRequestException("An employee with this email already exists");
        }
        Employee employee = new Employee();
        applyDto(employee, dto);
        return toDto(employeeRepository.save(employee));
    }

    @Transactional
    public EmployeeDto update(Long id, EmployeeDto dto) {
        Employee employee = findEntity(id);
        applyDto(employee, dto);
        return toDto(employeeRepository.save(employee));
    }

    @Transactional
    public void delete(Long id) {
        Employee employee = findEntity(id);
        employeeRepository.delete(employee);
    }

    private Employee findEntity(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
    }

    private void applyDto(Employee employee, EmployeeDto dto) {
        employee.setName(dto.getName());
        employee.setEmail(dto.getEmail());
        employee.setDepartment(dto.getDepartment());
        employee.setDesignation(dto.getDesignation());
        employee.setPhone(dto.getPhone());
    }

    private EmployeeDto toDto(Employee e) {
        EmployeeDto dto = new EmployeeDto();
        dto.setId(e.getId());
        dto.setName(e.getName());
        dto.setEmail(e.getEmail());
        dto.setDepartment(e.getDepartment());
        dto.setDesignation(e.getDesignation());
        dto.setPhone(e.getPhone());
        if (e.getUser() != null) {
            dto.setUserId(e.getUser().getId());
            dto.setUsername(e.getUser().getUsername());
        }
        return dto;
    }
}
