package com.assettrak.repository;

import com.assettrak.model.MaintenanceRequest;
import com.assettrak.model.RequestStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MaintenanceRequestRepository extends JpaRepository<MaintenanceRequest, Long> {
    Page<MaintenanceRequest> findByRequestedById(Long employeeId, Pageable pageable);
    Page<MaintenanceRequest> findByStatus(RequestStatus status, Pageable pageable);
}
