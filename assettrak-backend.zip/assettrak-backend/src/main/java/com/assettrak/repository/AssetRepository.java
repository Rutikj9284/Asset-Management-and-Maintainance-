package com.assettrak.repository;

import com.assettrak.model.Asset;
import com.assettrak.model.AssetStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AssetRepository extends JpaRepository<Asset, Long> {
    boolean existsBySerialNumber(String serialNumber);
    Page<Asset> findByAssignedToId(Long employeeId, Pageable pageable);
    Page<Asset> findByStatus(AssetStatus status, Pageable pageable);
    Page<Asset> findByNameContainingIgnoreCaseOrSerialNumberContainingIgnoreCase(
            String name, String serialNumber, Pageable pageable);
}
