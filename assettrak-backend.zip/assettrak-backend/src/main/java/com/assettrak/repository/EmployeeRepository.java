package com.assettrak.repository;

import com.assettrak.model.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Optional<Employee> findByUserId(Long userId);
    Optional<Employee> findByEmail(String email);
    Page<Employee> findByNameContainingIgnoreCase(String name, Pageable pageable);
}
