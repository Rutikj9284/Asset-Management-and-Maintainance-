# AssetTrak — Sprint 2 Frontend (Angular)

## Stack
- Angular 17 (standalone components, functional guards/interceptors)
- Reactive Forms with validation
- Signal-based auth state
- Custom pagination component (backed by Spring Data `Pageable` on the backend)

## Setup
```
npm install
npm start
```
Runs on `http://localhost:4200` and expects the backend at `http://localhost:8080/api`
(see `src/environments/environment.ts` to change the API URL).

## Structure
```
src/app/
  core/          # models, services (auth/asset/employee/request), guards, JWT interceptor
  shared/        # navbar, pagination components
  pages/
    landing/     # public landing page
    login/       # login with validation
    register/    # registration with validation (password strength, confirm match)
    admin/       # dashboard, assets CRUD, employees CRUD, requests approve/reject
    user/        # dashboard, my-assets, my-requests (raise + track)
```

## Demo accounts
| Role  | Username | Password   |
|-------|----------|------------|
| Admin | admin    | Admin@123  |
| User  | jdoe     | User@123   |

Registering a new account always creates a **USER** role account.

## Notes
- All list views (assets, employees, requests) use server-side pagination via `?page=&size=`.
- Background uses an animated gradient (`src/styles.css`); cards/buttons have subtle hover/transition animations.
- Admin can perform full CRUD on Assets and Employees, assign/unassign assets, and approve/reject maintenance requests.
- Users can view their assigned assets and raise/track maintenance requests.
