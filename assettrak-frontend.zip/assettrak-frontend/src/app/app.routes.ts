import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { adminGuard } from './core/guards/admin.guard';
import { guestGuard } from './core/guards/guest.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./pages/landing/landing.component').then((m) => m.LandingComponent),
  },
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import('./pages/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'register',
    canActivate: [guestGuard],
    loadComponent: () =>
      import('./pages/register/register.component').then((m) => m.RegisterComponent),
  },
  {
    path: 'admin',
    canActivate: [authGuard, adminGuard],
    children: [
      {
        path: '',
        loadComponent: () =>
          import('./pages/admin/admin-dashboard/admin-dashboard.component').then(
            (m) => m.AdminDashboardComponent
          ),
      },
      {
        path: 'assets',
        loadComponent: () =>
          import('./pages/admin/assets/assets.component').then((m) => m.AssetsComponent),
      },
      {
        path: 'employees',
        loadComponent: () =>
          import('./pages/admin/employees/employees.component').then(
            (m) => m.EmployeesComponent
          ),
      },
      {
        path: 'requests',
        loadComponent: () =>
          import('./pages/admin/requests/admin-requests.component').then(
            (m) => m.AdminRequestsComponent
          ),
      },
    ],
  },
  {
    path: 'user',
    canActivate: [authGuard],
    children: [
      {
        path: '',
        loadComponent: () =>
          import('./pages/user/user-dashboard/user-dashboard.component').then(
            (m) => m.UserDashboardComponent
          ),
      },
      {
        path: 'my-assets',
        loadComponent: () =>
          import('./pages/user/my-assets/my-assets.component').then(
            (m) => m.MyAssetsComponent
          ),
      },
      {
        path: 'my-requests',
        loadComponent: () =>
          import('./pages/user/my-requests/my-requests.component').then(
            (m) => m.MyRequestsComponent
          ),
      },
    ],
  },
  {
    path: '**',
    loadComponent: () =>
      import('./pages/not-found/not-found.component').then((m) => m.NotFoundComponent),
  },
];
