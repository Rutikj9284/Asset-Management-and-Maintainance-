import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <nav class="navbar">
      <div class="navbar-inner">
        <a class="brand" [routerLink]="auth.isAdmin() ? '/admin' : '/user'">
          <span class="brand-icon">📦</span> AssetTrak
        </a>

        <div class="links" *ngIf="auth.isLoggedIn()">
          <ng-container *ngIf="auth.isAdmin(); else userLinks">
            <a routerLink="/admin" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">Dashboard</a>
            <a routerLink="/admin/assets" routerLinkActive="active">Assets</a>
            <a routerLink="/admin/employees" routerLinkActive="active">Employees</a>
            <a routerLink="/admin/requests" routerLinkActive="active">Requests</a>
          </ng-container>
          <ng-template #userLinks>
            <a routerLink="/user" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">Dashboard</a>
            <a routerLink="/user/my-assets" routerLinkActive="active">My Assets</a>
            <a routerLink="/user/my-requests" routerLinkActive="active">My Requests</a>
          </ng-template>
        </div>

        <div class="user-area" *ngIf="auth.isLoggedIn()">
          <span class="hello">Hi, {{ auth.currentUser()?.fullName }}</span>
          <button class="btn btn-outline btn-sm" (click)="logout()">Logout</button>
        </div>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      background: rgba(255,255,255,0.85);
      backdrop-filter: blur(12px);
      box-shadow: 0 2px 12px rgba(30,27,58,0.08);
      position: sticky;
      top: 0;
      z-index: 20;
    }
    .navbar-inner {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0.85rem 1.5rem;
      display: flex;
      align-items: center;
      gap: 2rem;
    }
    .brand {
      font-family: 'Poppins', sans-serif;
      font-weight: 700;
      font-size: 1.2rem;
      color: #4338ca;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }
    .links {
      display: flex;
      gap: 1.4rem;
      flex: 1;
    }
    .links a {
      text-decoration: none;
      color: #4b5563;
      font-weight: 500;
      font-size: 0.92rem;
      padding: 0.4rem 0;
      border-bottom: 2px solid transparent;
      transition: color 0.2s ease, border-color 0.2s ease;
    }
    .links a:hover { color: #6366f1; }
    .links a.active { color: #6366f1; border-color: #6366f1; }
    .user-area {
      margin-left: auto;
      display: flex;
      align-items: center;
      gap: 0.9rem;
    }
    .hello { font-size: 0.88rem; color: #4b5563; }
    @media (max-width: 720px) {
      .navbar-inner { flex-wrap: wrap; gap: 0.6rem; }
      .links { order: 3; width: 100%; gap: 1rem; }
      .user-area { margin-left: 0; }
    }
  `],
})
export class NavbarComponent {
  constructor(public auth: AuthService, private router: Router) {}

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
