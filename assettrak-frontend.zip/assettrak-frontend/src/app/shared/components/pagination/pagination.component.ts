import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="pagination" *ngIf="totalPages > 1">
      <button class="btn btn-outline btn-sm" (click)="go(page - 1)" [disabled]="page === 0">‹ Prev</button>

      <span class="pages">
        <button
          *ngFor="let p of pageNumbers"
          class="page-btn"
          [class.active]="p === page"
          (click)="go(p)">
          {{ p + 1 }}
        </button>
      </span>

      <button class="btn btn-outline btn-sm" (click)="go(page + 1)" [disabled]="page >= totalPages - 1">Next ›</button>
    </div>
  `,
  styles: [`
    .pagination {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.6rem;
      margin-top: 1.5rem;
      flex-wrap: wrap;
    }
    .pages { display: flex; gap: 0.35rem; }
    .page-btn {
      border: 1.5px solid #e2e2f0;
      background: #fff;
      width: 34px;
      height: 34px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
      color: #4b5563;
      transition: all 0.15s ease;
    }
    .page-btn:hover { border-color: #6366f1; color: #6366f1; }
    .page-btn.active {
      background: linear-gradient(135deg, #6366f1, #a855f7);
      color: #fff;
      border-color: transparent;
    }
  `],
})
export class PaginationComponent {
  @Input() page = 0;
  @Input() totalPages = 0;
  @Output() pageChange = new EventEmitter<number>();

  get pageNumbers(): number[] {
    const maxButtons = 5;
    let start = Math.max(0, this.page - Math.floor(maxButtons / 2));
    const end = Math.min(this.totalPages, start + maxButtons);
    start = Math.max(0, end - maxButtons);
    return Array.from({ length: end - start }, (_, i) => start + i);
  }

  go(p: number): void {
    if (p < 0 || p >= this.totalPages || p === this.page) return;
    this.pageChange.emit(p);
  }
}
