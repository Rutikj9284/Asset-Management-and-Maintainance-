import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Asset, PageResponse } from '../models/models';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AssetService {
  private base = `${environment.apiUrl}/assets`;

  constructor(private http: HttpClient) {}

  list(page: number, size: number, search?: string, status?: string): Observable<PageResponse<Asset>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (search) params = params.set('search', search);
    if (status) params = params.set('status', status);
    return this.http.get<PageResponse<Asset>>(this.base, { params });
  }

  myAssets(page: number, size: number): Observable<PageResponse<Asset>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<PageResponse<Asset>>(`${this.base}/my-assets`, { params });
  }

  get(id: number): Observable<Asset> {
    return this.http.get<Asset>(`${this.base}/${id}`);
  }

  create(asset: Asset): Observable<Asset> {
    return this.http.post<Asset>(this.base, asset);
  }

  update(id: number, asset: Asset): Observable<Asset> {
    return this.http.put<Asset>(`${this.base}/${id}`, asset);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.base}/${id}`);
  }

  assign(id: number, employeeId: number | null): Observable<Asset> {
    return this.http.patch<Asset>(`${this.base}/${id}/assign`, { employeeId });
  }
}
