import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MaintenanceRequest, PageResponse } from '../models/models';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class RequestService {
  private base = `${environment.apiUrl}/requests`;

  constructor(private http: HttpClient) {}

  list(page: number, size: number, status?: string): Observable<PageResponse<MaintenanceRequest>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (status) params = params.set('status', status);
    return this.http.get<PageResponse<MaintenanceRequest>>(this.base, { params });
  }

  myRequests(page: number, size: number): Observable<PageResponse<MaintenanceRequest>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<PageResponse<MaintenanceRequest>>(`${this.base}/my-requests`, { params });
  }

  create(request: { assetId: number; description: string }): Observable<MaintenanceRequest> {
    return this.http.post<MaintenanceRequest>(this.base, request);
  }

  approve(id: number, adminRemarks?: string): Observable<MaintenanceRequest> {
    return this.http.patch<MaintenanceRequest>(`${this.base}/${id}/approve`, { adminRemarks });
  }

  reject(id: number, adminRemarks?: string): Observable<MaintenanceRequest> {
    return this.http.patch<MaintenanceRequest>(`${this.base}/${id}/reject`, { adminRemarks });
  }
}
