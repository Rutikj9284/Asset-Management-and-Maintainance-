export type UserRole = 'ADMIN' | 'USER';

export interface AuthResponse {
  token: string;
  userId: number;
  username: string;
  fullName: string;
  role: UserRole;
}

export interface RegisterPayload {
  username: string;
  fullName: string;
  email: string;
  password: string;
}

export interface LoginPayload {
  username: string;
  password: string;
}

export type AssetStatus = 'AVAILABLE' | 'ASSIGNED' | 'IN_MAINTENANCE' | 'RETIRED';

export interface Asset {
  id?: number;
  name: string;
  type: string;
  serialNumber: string;
  status?: AssetStatus;
  purchaseDate?: string | null;
  location?: string;
  assignedToEmployeeId?: number | null;
  assignedToEmployeeName?: string | null;
}

export interface Employee {
  id?: number;
  name: string;
  email: string;
  department?: string;
  designation?: string;
  phone?: string;
  userId?: number | null;
  username?: string | null;
}

export type RequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED';

export interface MaintenanceRequest {
  id?: number;
  assetId: number;
  assetName?: string;
  assetSerialNumber?: string;
  requestedByEmployeeId?: number;
  requestedByEmployeeName?: string;
  description: string;
  status?: RequestStatus;
  requestDate?: string;
  resolvedDate?: string | null;
  adminRemarks?: string | null;
}

export interface PageResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  last: boolean;
}

export interface ApiError {
  timestamp: string;
  status: number;
  message: string;
  fieldErrors?: Record<string, string> | null;
}
