import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="auth-page">
      <div class="card auth-card fade-in">
        <div class="auth-icon">🔐</div>
        <h2>Welcome back</h2>
        <p class="subtitle">Sign in to your AssetTrak account</p>

        <div class="alert alert-danger" *ngIf="serverError">{{ serverError }}</div>

        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="form-group">
            <label for="username">Username</label>
            <input
              id="username"
              type="text"
              class="form-control"
              formControlName="username"
              [class.is-invalid]="isInvalid('username')"
              placeholder="Enter your username" />
            <span class="error-text" *ngIf="isInvalid('username')">Username is required</span>
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input
              id="password"
              type="password"
              class="form-control"
              formControlName="password"
              [class.is-invalid]="isInvalid('password')"
              placeholder="Enter your password" />
            <span class="error-text" *ngIf="isInvalid('password')">Password is required</span>
          </div>

          <button type="submit" class="btn btn-primary full" [disabled]="loading">
            <span class="spinner" *ngIf="loading"></span>
            {{ loading ? 'Signing in...' : 'Sign In' }}
          </button>
        </form>

        <p class="switch">
          Don't have an account? <a routerLink="/register">Create one</a>
        </p>

        <div class="demo-hint">
          Demo — Admin: <code>admin / Admin@123</code> · User: <code>jdoe / User@123</code>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }
    .auth-card {
      max-width: 400px;
      width: 100%;
      text-align: center;
    }
    .auth-icon { font-size: 2.2rem; margin-bottom: 0.5rem; }
    h2 { margin-bottom: 0.3rem; }
    .subtitle { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.6rem; }
    .full { width: 100%; margin-top: 0.4rem; }
    .switch { margin-top: 1.2rem; font-size: 0.88rem; color: var(--text-muted); }
    .switch a { color: var(--primary); font-weight: 600; text-decoration: none; }
    .demo-hint {
      margin-top: 1.4rem;
      font-size: 0.75rem;
      color: var(--text-muted);
      background: #f5f5fb;
      padding: 0.6rem;
      border-radius: 8px;
    }
    code { color: var(--primary-dark); }
  `],
})
export class LoginComponent {
  loading = false;
  serverError = '';

  form = this.fb.group({
    username: ['', [Validators.required]],
    password: ['', [Validators.required]],
  });

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  submit(): void {
    this.serverError = '';
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;
    const { username, password } = this.form.getRawValue();
    this.auth.login({ username: username!, password: password! }).subscribe({
      next: (res) => {
        this.loading = false;
        this.router.navigate([res.role === 'ADMIN' ? '/admin' : '/user']);
      },
      error: (err) => {
        this.loading = false;
        this.serverError = err?.error?.message || 'Invalid username or password';
      },
    });
  }
}
