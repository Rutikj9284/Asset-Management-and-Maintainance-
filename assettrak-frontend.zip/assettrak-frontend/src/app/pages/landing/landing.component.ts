import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="landing">
      <div class="glow glow-1"></div>
      <div class="glow glow-2"></div>

      <div class="hero">
        <div class="badge-pill">📦 Asset Lifecycle Management</div>
        <h1>Track. Assign. Maintain.<br />All in one place.</h1>
        <p>
          AssetTrak helps your organization manage physical assets end to end —
          from assignment and accountability to maintenance requests and approvals.
        </p>

        <div class="cta-row">
          <a routerLink="/register" class="btn btn-primary">Get Started</a>
          <a routerLink="/login" class="btn btn-outline light">Sign In</a>
        </div>
      </div>

      <div class="features">
        <div class="card feature">
          <div class="icon">🗂️</div>
          <h3>Asset Management</h3>
          <p>Create, update, and track every asset's status and location in real time.</p>
        </div>
        <div class="card feature">
          <div class="icon">👥</div>
          <h3>Employee Assignments</h3>
          <p>Assign assets to employees and maintain full accountability history.</p>
        </div>
        <div class="card feature">
          <div class="icon">🛠️</div>
          <h3>Maintenance Requests</h3>
          <p>Employees raise requests; admins approve or reject with a click.</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .landing {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 3rem 1.5rem;
      position: relative;
      overflow: hidden;
      text-align: center;
    }
    .glow {
      position: absolute;
      border-radius: 50%;
      filter: blur(80px);
      opacity: 0.5;
      animation: float 10s ease-in-out infinite;
    }
    .glow-1 {
      width: 320px; height: 320px;
      background: #a855f7;
      top: -80px; left: -80px;
    }
    .glow-2 {
      width: 380px; height: 380px;
      background: #06b6d4;
      bottom: -100px; right: -100px;
      animation-delay: 2s;
    }
    @keyframes float {
      0%, 100% { transform: translate(0, 0); }
      50% { transform: translate(30px, 20px); }
    }
    .hero {
      max-width: 720px;
      color: #fff;
      z-index: 1;
      animation: fadeInUp 0.6s ease both;
    }
    .badge-pill {
      display: inline-block;
      background: rgba(255,255,255,0.18);
      border: 1px solid rgba(255,255,255,0.35);
      padding: 0.4rem 1rem;
      border-radius: 999px;
      font-size: 0.82rem;
      margin-bottom: 1.4rem;
    }
    h1 {
      font-size: 2.6rem;
      line-height: 1.2;
      margin-bottom: 1.1rem;
    }
    .hero p {
      font-size: 1.05rem;
      opacity: 0.9;
      margin-bottom: 2rem;
    }
    .cta-row {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
    }
    .btn-outline.light {
      border-color: #fff;
      color: #fff;
    }
    .btn-outline.light:hover { background: rgba(255,255,255,0.12); }
    .features {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 1.5rem;
      max-width: 1000px;
      width: 100%;
      margin-top: 3.5rem;
      z-index: 1;
    }
    .feature { text-align: center; }
    .feature .icon { font-size: 2rem; margin-bottom: 0.6rem; }
    .feature h3 { margin-bottom: 0.5rem; font-size: 1.05rem; }
    .feature p { color: var(--text-muted); font-size: 0.9rem; }
    @media (max-width: 600px) {
      h1 { font-size: 2rem; }
    }
  `],
})
export class LandingComponent {}
