import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

function passwordStrength(control: AbstractControl): ValidationErrors | null {
  const value = control.value as string;
  if (!value) return null;
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  return hasUpper && hasLower && hasDigit ? null : { weakPassword: true };
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="auth-page">
      <div class="card auth-card fade-in">
        <div class="auth-icon">✨</div>
        <h2>Create your account</h2>
        <p class="subtitle">Join AssetTrak to track your assigned assets</p>

        <div class="alert alert-danger" *ngIf="serverError">{{ serverError }}</div>
        <div class="alert alert-success" *ngIf="success">Account created! Redirecting...</div>

        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="form-group">
            <label for="fullName">Full name</label>
            <input
              id="fullName"
              type="text"
              class="form-control"
              formControlName="fullName"
              [class.is-invalid]="isInvalid('fullName')"
              placeholder="e.g. Jane Cooper" />
            <span class="error-text" *ngIf="isInvalid('fullName')">Full name must be 2–100 characters</span>
          </div>

          <div class="form-group">
            <label for="username">Username</label>
            <input
              id="username"
              type="text"
              class="form-control"
              formControlName="username"
              [class.is-invalid]="isInvalid('username')"
              placeholder="e.g. jane.cooper" />
            <span class="error-text" *ngIf="isInvalid('username')">
              4–30 characters — letters, numbers, dots and underscores only
            </span>
          </div>

          <div class="form-group">
            <label for="email">Email</label>
            <input
              id="email"
              type="email"
              class="form-control"
              formControlName="email"
              [class.is-invalid]="isInvalid('email')"
              placeholder="you@company.com" />
            <span class="error-text" *ngIf="isInvalid('email')">Enter a valid email address</span>
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input
              id="password"
              type="password"
              class="form-control"
              formControlName="password"
              [class.is-invalid]="isInvalid('password')"
              placeholder="At least 8 characters" />
            <span class="error-text" *ngIf="form.get('password')?.hasError('required') && isInvalid('password')">
              Password is required
            </span>
            <span class="error-text" *ngIf="form.get('password')?.hasError('minlength') && isInvalid('password')">
              Password must be at least 8 characters
            </span>
            <span class="error-text" *ngIf="form.get('password')?.hasError('weakPassword') && isInvalid('password')">
              Must include an uppercase letter, lowercase letter, and a number
            </span>
          </div>

          <div class="form-group">
            <label for="confirmPassword">Confirm password</label>
            <input
              id="confirmPassword"
              type="password"
              class="form-control"
              formControlName="confirmPassword"
              [class.is-invalid]="isInvalid('confirmPassword') || (form.hasError('mismatch') && form.get('confirmPassword')?.touched)"
              placeholder="Re-enter your password" />
            <span class="error-text" *ngIf="form.hasError('mismatch') && form.get('confirmPassword')?.touched">
              Passwords do not match
            </span>
          </div>

          <button type="submit" class="btn btn-primary full" [disabled]="loading">
            <span class="spinner" *ngIf="loading"></span>
            {{ loading ? 'Creating account...' : 'Create Account' }}
          </button>
        </form>

        <p class="switch">
          Already have an account? <a routerLink="/login">Sign in</a>
        </p>
      </div>
    </div>
  `,
  styles: [`
    .auth-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }
    .auth-card { max-width: 420px; width: 100%; text-align: center; }
    .auth-icon { font-size: 2.2rem; margin-bottom: 0.5rem; }
    h2 { margin-bottom: 0.3rem; }
    .subtitle { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.6rem; }
    .full { width: 100%; margin-top: 0.4rem; }
    .switch { margin-top: 1.2rem; font-size: 0.88rem; color: var(--text-muted); }
    .switch a { color: var(--primary); font-weight: 600; text-decoration: none; }
  `],
})
export class RegisterComponent {
  loading = false;
  success = false;
  serverError = '';

  form = this.fb.group(
    {
      fullName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      username: [
        '',
        [Validators.required, Validators.minLength(4), Validators.maxLength(30), Validators.pattern(/^[a-zA-Z0-9._]+$/)],
      ],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8), passwordStrength]],
      confirmPassword: ['', [Validators.required]],
    },
    { validators: this.matchPasswords }
  );

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  matchPasswords(group: AbstractControl): ValidationErrors | null {
    const pass = group.get('password')?.value;
    const confirm = group.get('confirmPassword')?.value;
    return pass === confirm ? null : { mismatch: true };
  }

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  submit(): void {
    this.serverError = '';
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;
    const { fullName, username, email, password } = this.form.getRawValue();
    this.auth.register({ fullName: fullName!, username: username!, email: email!, password: password! }).subscribe({
      next: () => {
        this.loading = false;
        this.success = true;
        setTimeout(() => this.router.navigate(['/user']), 900);
      },
      error: (err) => {
        this.loading = false;
        this.serverError = err?.error?.message || 'Registration failed. Please try again.';
      },
    });
  }
}
