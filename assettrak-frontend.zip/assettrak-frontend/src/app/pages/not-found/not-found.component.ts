import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="wrap">
      <div class="card fade-in">
        <h1>404</h1>
        <p>Page not found.</p>
        <a routerLink="/" class="btn btn-primary">Go Home</a>
      </div>
    </div>
  `,
  styles: [`
    .wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; }
    .card { text-align: center; }
    h1 { font-size: 3rem; background: linear-gradient(135deg, #6366f1, #a855f7); -webkit-background-clip: text; background-clip: text; color: transparent; }
    p { margin: 0.6rem 0 1.4rem; color: var(--text-muted); }
  `],
})
export class NotFoundComponent {}
