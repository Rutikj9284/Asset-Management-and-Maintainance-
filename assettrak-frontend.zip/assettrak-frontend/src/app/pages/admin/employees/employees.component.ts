import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NavbarComponent } from '../../../shared/components/navbar/navbar.component';
import { PaginationComponent } from '../../../shared/components/pagination/pagination.component';
import { EmployeeService } from '../../../core/services/employee.service';
import { Employee } from '../../../core/models/models';

@Component({
  selector: 'app-employees',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, NavbarComponent, PaginationComponent],
  template: `
    <div class="app-shell">
      <app-navbar></app-navbar>
      <div class="page-container">
        <div class="header-row">
          <div>
            <h2 class="page-title">Employees</h2>
            <p class="page-subtitle">Maintain employee records</p>
          </div>
          <button class="btn btn-primary" (click)="openCreate()">+ Add Employee</button>
        </div>

        <div class="card toolbar">
          <input
            class="form-control"
            placeholder="Search by name..."
            [(ngModel)]="search"
            [ngModelOptions]="{standalone: true}"
            (keyup.enter)="reload()" />
          <button class="btn btn-outline" (click)="reload()">Search</button>
        </div>

        <div class="alert alert-danger" *ngIf="error">{{ error }}</div>

        <div class="card table-card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Name</th><th>Email</th><th>Department</th><th>Designation</th><th>Phone</th><th>Linked Login</th><th>Actions</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let emp of employees">
                  <td>{{ emp.name }}</td>
                  <td>{{ emp.email }}</td>
                  <td>{{ emp.department || '—' }}</td>
                  <td>{{ emp.designation || '—' }}</td>
                  <td>{{ emp.phone || '—' }}</td>
                  <td>{{ emp.username || '—' }}</td>
                  <td class="actions">
                    <button class="btn btn-outline btn-sm" (click)="openEdit(emp)">Edit</button>
                    <button class="btn btn-danger btn-sm" (click)="remove(emp)">Delete</button>
                  </td>
                </tr>
                <tr *ngIf="!employees.length && !loading">
                  <td colspan="7" class="empty">No employees found.</td>
                </tr>
              </tbody>
            </table>
          </div>
          <app-pagination [page]="page" [totalPages]="totalPages" (pageChange)="onPageChange($event)"></app-pagination>
        </div>
      </div>

      <div class="modal-backdrop" *ngIf="showForm" (click)="closeForm()">
        <div class="card modal fade-in" (click)="$event.stopPropagation()">
          <h3>{{ editingId ? 'Edit Employee' : 'Add Employee' }}</h3>
          <form [formGroup]="form" (ngSubmit)="save()">
            <div class="form-group">
              <label>Name</label>
              <input class="form-control" formControlName="name" [class.is-invalid]="isInvalid('name')" />
              <span class="error-text" *ngIf="isInvalid('name')">Name is required</span>
            </div>
            <div class="form-group">
              <label>Email</label>
              <input class="form-control" formControlName="email" [class.is-invalid]="isInvalid('email')" />
              <span class="error-text" *ngIf="isInvalid('email')">A valid email is required</span>
            </div>
            <div class="form-group">
              <label>Department</label>
              <input class="form-control" formControlName="department" />
            </div>
            <div class="form-group">
              <label>Designation</label>
              <input class="form-control" formControlName="designation" />
            </div>
            <div class="form-group">
              <label>Phone</label>
              <input class="form-control" formControlName="phone" />
            </div>
            <div class="modal-actions">
              <button type="button" class="btn btn-outline" (click)="closeForm()">Cancel</button>
              <button type="submit" class="btn btn-primary" [disabled]="saving">
                {{ saving ? 'Saving...' : 'Save' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .header-row { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.2rem; flex-wrap: wrap; gap: 1rem; }
    .page-title { color: #fff; margin-bottom: 0.15rem; }
    .page-subtitle { color: rgba(255,255,255,0.85); font-size: 0.9rem; }
    .toolbar { display: flex; gap: 0.8rem; margin-bottom: 1.2rem; flex-wrap: wrap; }
    .toolbar .form-control { max-width: 320px; }
    .table-card { padding: 1.2rem; }
    .actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }
    .empty { text-align: center; color: var(--text-muted); padding: 2rem 0; }
    .modal-backdrop {
      position: fixed; inset: 0; background: rgba(20, 18, 40, 0.55);
      display: flex; align-items: center; justify-content: center; z-index: 50; padding: 1rem;
      backdrop-filter: blur(2px);
    }
    .modal { max-width: 440px; width: 100%; max-height: 90vh; overflow-y: auto; }
    .modal h3 { margin-bottom: 1.1rem; }
    .modal-actions { display: flex; justify-content: flex-end; gap: 0.7rem; margin-top: 0.6rem; }
  `],
})
export class EmployeesComponent implements OnInit {
  employees: Employee[] = [];
  page = 0;
  size = 5;
  totalPages = 0;
  loading = false;
  error = '';
  search = '';

  showForm = false;
  editingId: number | null = null;
  saving = false;

  form = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    department: [''],
    designation: [''],
    phone: [''],
  });

  constructor(private fb: FormBuilder, private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.reload();
  }

  reload(): void {
    this.loading = true;
    this.error = '';
    this.employeeService.list(this.page, this.size, this.search || undefined).subscribe({
      next: (res) => {
        this.employees = res.content;
        this.totalPages = res.totalPages;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load employees.';
        this.loading = false;
      },
    });
  }

  onPageChange(p: number): void {
    this.page = p;
    this.reload();
  }

  isInvalid(name: string): boolean {
    const c = this.form.get(name);
    return !!c && c.invalid && (c.dirty || c.touched);
  }

  openCreate(): void {
    this.editingId = null;
    this.form.reset();
    this.showForm = true;
  }

  openEdit(emp: Employee): void {
    this.editingId = emp.id!;
    this.form.reset({
      name: emp.name,
      email: emp.email,
      department: emp.department || '',
      designation: emp.designation || '',
      phone: emp.phone || '',
    });
    this.showForm = true;
  }

  closeForm(): void {
    this.showForm = false;
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving = true;
    const payload = this.form.getRawValue() as unknown as Employee;
    const request = this.editingId
      ? this.employeeService.update(this.editingId, payload)
      : this.employeeService.create(payload);

    request.subscribe({
      next: () => {
        this.saving = false;
        this.showForm = false;
        this.reload();
      },
      error: (err) => {
        this.saving = false;
        this.error = err?.error?.message || 'Failed to save employee.';
      },
    });
  }

  remove(emp: Employee): void {
    if (!confirm(`Delete employee "${emp.name}"?`)) return;
    this.employeeService.delete(emp.id!).subscribe({
      next: () => this.reload(),
      error: () => (this.error = 'Failed to delete employee.'),
    });
  }
}
