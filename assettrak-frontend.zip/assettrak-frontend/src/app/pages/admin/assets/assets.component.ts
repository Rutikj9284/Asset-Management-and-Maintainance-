import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { NavbarComponent } from '../../../shared/components/navbar/navbar.component';
import { PaginationComponent } from '../../../shared/components/pagination/pagination.component';
import { AssetService } from '../../../core/services/asset.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { Asset, Employee } from '../../../core/models/models';

@Component({
  selector: 'app-assets',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, NavbarComponent, PaginationComponent],
  template: `
    <div class="app-shell">
      <app-navbar></app-navbar>
      <div class="page-container">
        <div class="header-row">
          <div>
            <h2 class="page-title">Assets</h2>
            <p class="page-subtitle">Manage your organization's physical assets</p>
          </div>
          <button class="btn btn-primary" (click)="openCreate()">+ Add Asset</button>
        </div>

        <div class="card toolbar">
          <input
            class="form-control"
            placeholder="Search by name or serial number..."
            [(ngModel)]="search"
            [ngModelOptions]="{standalone: true}"
            (keyup.enter)="reload()" />
          <select class="form-control status-select" [(ngModel)]="statusFilter" [ngModelOptions]="{standalone: true}" (change)="reload()">
            <option value="">All statuses</option>
            <option value="AVAILABLE">Available</option>
            <option value="ASSIGNED">Assigned</option>
            <option value="IN_MAINTENANCE">In Maintenance</option>
            <option value="RETIRED">Retired</option>
          </select>
          <button class="btn btn-outline" (click)="reload()">Search</button>
        </div>

        <div class="alert alert-danger" *ngIf="error">{{ error }}</div>

        <div class="card table-card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th><th>Type</th><th>Serial No.</th><th>Status</th>
                  <th>Assigned To</th><th>Location</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let asset of assets">
                  <td>{{ asset.name }}</td>
                  <td>{{ asset.type }}</td>
                  <td>{{ asset.serialNumber }}</td>
                  <td><span class="badge" [ngClass]="'badge-' + (asset.status || '').toLowerCase()">{{ asset.status }}</span></td>
                  <td>{{ asset.assignedToEmployeeName || '—' }}</td>
                  <td>{{ asset.location || '—' }}</td>
                  <td class="actions">
                    <button class="btn btn-outline btn-sm" (click)="openAssign(asset)">Assign</button>
                    <button class="btn btn-outline btn-sm" (click)="openEdit(asset)">Edit</button>
                    <button class="btn btn-danger btn-sm" (click)="remove(asset)">Delete</button>
                  </td>
                </tr>
                <tr *ngIf="!assets.length && !loading">
                  <td colspan="7" class="empty">No assets found.</td>
                </tr>
              </tbody>
            </table>
          </div>
          <app-pagination [page]="page" [totalPages]="totalPages" (pageChange)="onPageChange($event)"></app-pagination>
        </div>
      </div>

      <!-- Create / Edit Modal -->
      <div class="modal-backdrop" *ngIf="showForm" (click)="closeForm()">
        <div class="card modal fade-in" (click)="$event.stopPropagation()">
          <h3>{{ editingId ? 'Edit Asset' : 'Add Asset' }}</h3>
          <form [formGroup]="form" (ngSubmit)="save()">
            <div class="form-group">
              <label>Name</label>
              <input class="form-control" formControlName="name" [class.is-invalid]="isInvalid('name')" />
              <span class="error-text" *ngIf="isInvalid('name')">Name is required</span>
            </div>
            <div class="form-group">
              <label>Type</label>
              <input class="form-control" formControlName="type" [class.is-invalid]="isInvalid('type')" placeholder="e.g. Laptop, Monitor" />
              <span class="error-text" *ngIf="isInvalid('type')">Type is required</span>
            </div>
            <div class="form-group">
              <label>Serial Number</label>
              <input class="form-control" formControlName="serialNumber" [class.is-invalid]="isInvalid('serialNumber')" />
              <span class="error-text" *ngIf="isInvalid('serialNumber')">Serial number is required</span>
            </div>
            <div class="form-group">
              <label>Purchase Date</label>
              <input class="form-control" type="date" formControlName="purchaseDate" />
            </div>
            <div class="form-group">
              <label>Location</label>
              <input class="form-control" formControlName="location" />
            </div>
            <div class="modal-actions">
              <button type="button" class="btn btn-outline" (click)="closeForm()">Cancel</button>
              <button type="submit" class="btn btn-primary" [disabled]="saving">
                {{ saving ? 'Saving...' : 'Save' }}
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Assign Modal -->
      <div class="modal-backdrop" *ngIf="showAssign" (click)="closeAssign()">
        <div class="card modal fade-in" (click)="$event.stopPropagation()">
          <h3>Assign "{{ assigningAsset?.name }}"</h3>
          <div class="form-group">
            <label>Employee</label>
            <select class="form-control" [(ngModel)]="assignEmployeeId" [ngModelOptions]="{standalone: true}">
              <option [ngValue]="null">Unassign</option>
              <option *ngFor="let emp of employees" [ngValue]="emp.id">{{ emp.name }} ({{ emp.department || 'N/A' }})</option>
            </select>
          </div>
          <div class="modal-actions">
            <button type="button" class="btn btn-outline" (click)="closeAssign()">Cancel</button>
            <button type="button" class="btn btn-primary" (click)="saveAssign()" [disabled]="saving">
              {{ saving ? 'Saving...' : 'Confirm' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .header-row { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.2rem; flex-wrap: wrap; gap: 1rem; }
    .page-title { color: #fff; margin-bottom: 0.15rem; }
    .page-subtitle { color: rgba(255,255,255,0.85); font-size: 0.9rem; }
    .toolbar { display: flex; gap: 0.8rem; margin-bottom: 1.2rem; flex-wrap: wrap; }
    .toolbar .form-control { max-width: 320px; }
    .status-select { max-width: 200px; }
    .table-card { padding: 1.2rem; }
    .actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }
    .empty { text-align: center; color: var(--text-muted); padding: 2rem 0; }
    .modal-backdrop {
      position: fixed; inset: 0; background: rgba(20, 18, 40, 0.55);
      display: flex; align-items: center; justify-content: center; z-index: 50; padding: 1rem;
      backdrop-filter: blur(2px);
    }
    .modal { max-width: 440px; width: 100%; max-height: 90vh; overflow-y: auto; }
    .modal h3 { margin-bottom: 1.1rem; }
    .modal-actions { display: flex; justify-content: flex-end; gap: 0.7rem; margin-top: 0.6rem; }
  `],
})
export class AssetsComponent implements OnInit {
  assets: Asset[] = [];
  employees: Employee[] = [];
  page = 0;
  size = 5;
  totalPages = 0;
  loading = false;
  error = '';
  search = '';
  statusFilter = '';

  showForm = false;
  editingId: number | null = null;
  saving = false;

  showAssign = false;
  assigningAsset: Asset | null = null;
  assignEmployeeId: number | null = null;

  form = this.fb.group({
    name: ['', Validators.required],
    type: ['', Validators.required],
    serialNumber: ['', Validators.required],
    purchaseDate: [''],
    location: [''],
  });

  constructor(
    private fb: FormBuilder,
    private assetService: AssetService,
    private employeeService: EmployeeService
  ) {}

  ngOnInit(): void {
    this.loadEmployees();
    this.reload();
  }

  loadEmployees(): void {
    this.employeeService.listAll().subscribe((res) => (this.employees = res.content));
  }

  reload(): void {
    this.loading = true;
    this.error = '';
    this.assetService.list(this.page, this.size, this.search || undefined, this.statusFilter || undefined).subscribe({
      next: (res) => {
        this.assets = res.content;
        this.totalPages = res.totalPages;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load assets.';
        this.loading = false;
      },
    });
  }

  onPageChange(p: number): void {
    this.page = p;
    this.reload();
  }

  isInvalid(name: string): boolean {
    const c = this.form.get(name);
    return !!c && c.invalid && (c.dirty || c.touched);
  }

  openCreate(): void {
    this.editingId = null;
    this.form.reset();
    this.showForm = true;
  }

  openEdit(asset: Asset): void {
    this.editingId = asset.id!;
    this.form.reset({
      name: asset.name,
      type: asset.type,
      serialNumber: asset.serialNumber,
      purchaseDate: asset.purchaseDate || '',
      location: asset.location || '',
    });
    this.showForm = true;
  }

  closeForm(): void {
    this.showForm = false;
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving = true;
    const payload = this.form.getRawValue() as unknown as Asset;
    const request = this.editingId
      ? this.assetService.update(this.editingId, payload)
      : this.assetService.create(payload);

    request.subscribe({
      next: () => {
        this.saving = false;
        this.showForm = false;
        this.reload();
      },
      error: (err) => {
        this.saving = false;
        this.error = err?.error?.message || 'Failed to save asset.';
      },
    });
  }

  remove(asset: Asset): void {
    if (!confirm(`Delete asset "${asset.name}"? This cannot be undone.`)) return;
    this.assetService.delete(asset.id!).subscribe({
      next: () => this.reload(),
      error: () => (this.error = 'Failed to delete asset.'),
    });
  }

  openAssign(asset: Asset): void {
    this.assigningAsset = asset;
    this.assignEmployeeId = asset.assignedToEmployeeId ?? null;
    this.showAssign = true;
  }

  closeAssign(): void {
    this.showAssign = false;
  }

  saveAssign(): void {
    if (!this.assigningAsset) return;
    this.saving = true;
    this.assetService.assign(this.assigningAsset.id!, this.assignEmployeeId).subscribe({
      next: () => {
        this.saving = false;
        this.showAssign = false;
        this.reload();
      },
      error: () => {
        this.saving = false;
        this.error = 'Failed to update assignment.';
      },
    });
  }
}
