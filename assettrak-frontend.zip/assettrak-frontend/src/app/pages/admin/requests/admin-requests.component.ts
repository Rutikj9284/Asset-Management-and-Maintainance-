import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../../../shared/components/navbar/navbar.component';
import { PaginationComponent } from '../../../shared/components/pagination/pagination.component';
import { RequestService } from '../../../core/services/request.service';
import { MaintenanceRequest } from '../../../core/models/models';

@Component({
  selector: 'app-admin-requests',
  standalone: true,
  imports: [CommonModule, FormsModule, NavbarComponent, PaginationComponent],
  template: `
    <div class="app-shell">
      <app-navbar></app-navbar>
      <div class="page-container">
        <div class="header-row">
          <div>
            <h2 class="page-title">Maintenance Requests</h2>
            <p class="page-subtitle">Review and act on employee requests</p>
          </div>
        </div>

        <div class="card toolbar">
          <select class="form-control status-select" [(ngModel)]="statusFilter" (change)="reload()">
            <option value="">All statuses</option>
            <option value="PENDING">Pending</option>
            <option value="APPROVED">Approved</option>
            <option value="REJECTED">Rejected</option>
            <option value="COMPLETED">Completed</option>
          </select>
        </div>

        <div class="alert alert-danger" *ngIf="error">{{ error }}</div>

        <div class="card table-card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Asset</th><th>Requested By</th><th>Description</th><th>Status</th><th>Requested On</th><th>Actions</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let req of requests">
                  <td>{{ req.assetName }} <br /><small>{{ req.assetSerialNumber }}</small></td>
                  <td>{{ req.requestedByEmployeeName }}</td>
                  <td class="desc-cell">{{ req.description }}</td>
                  <td><span class="badge" [ngClass]="'badge-' + (req.status || '').toLowerCase()">{{ req.status }}</span></td>
                  <td>{{ req.requestDate | date: 'medium' }}</td>
                  <td class="actions">
                    <ng-container *ngIf="req.status === 'PENDING'; else resolved">
                      <button class="btn btn-success btn-sm" (click)="decide(req, 'approve')">Approve</button>
                      <button class="btn btn-danger btn-sm" (click)="decide(req, 'reject')">Reject</button>
                    </ng-container>
                    <ng-template #resolved>
                      <span class="resolved-note" *ngIf="req.adminRemarks">{{ req.adminRemarks }}</span>
                      <span class="resolved-note" *ngIf="!req.adminRemarks">—</span>
                    </ng-template>
                  </td>
                </tr>
                <tr *ngIf="!requests.length && !loading">
                  <td colspan="6" class="empty">No requests found.</td>
                </tr>
              </tbody>
            </table>
          </div>
          <app-pagination [page]="page" [totalPages]="totalPages" (pageChange)="onPageChange($event)"></app-pagination>
        </div>
      </div>

      <div class="modal-backdrop" *ngIf="decisionTarget" (click)="cancelDecision()">
        <div class="card modal fade-in" (click)="$event.stopPropagation()">
          <h3>{{ decisionAction === 'approve' ? 'Approve' : 'Reject' }} Request</h3>
          <p class="modal-desc">{{ decisionTarget.description }}</p>
          <div class="form-group">
            <label>Remarks (optional)</label>
            <textarea class="form-control" rows="3" [(ngModel)]="remarks" [ngModelOptions]="{standalone: true}"></textarea>
          </div>
          <div class="modal-actions">
            <button type="button" class="btn btn-outline" (click)="cancelDecision()">Cancel</button>
            <button
              type="button"
              [class.btn-success]="decisionAction === 'approve'"
              [class.btn-danger]="decisionAction === 'reject'"
              class="btn"
              (click)="confirmDecision()"
              [disabled]="saving">
              {{ saving ? 'Saving...' : (decisionAction === 'approve' ? 'Confirm Approval' : 'Confirm Rejection') }}
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .header-row { margin-bottom: 1.2rem; }
    .page-title { color: #fff; margin-bottom: 0.15rem; }
    .page-subtitle { color: rgba(255,255,255,0.85); font-size: 0.9rem; }
    .toolbar { display: flex; gap: 0.8rem; margin-bottom: 1.2rem; }
    .status-select { max-width: 220px; }
    .table-card { padding: 1.2rem; }
    .desc-cell { max-width: 260px; }
    .actions { display: flex; gap: 0.5rem; flex-wrap: wrap; align-items: center; }
    .resolved-note { font-size: 0.82rem; color: var(--text-muted); }
    .empty { text-align: center; color: var(--text-muted); padding: 2rem 0; }
    .modal-backdrop {
      position: fixed; inset: 0; background: rgba(20, 18, 40, 0.55);
      display: flex; align-items: center; justify-content: center; z-index: 50; padding: 1rem;
    }
    .modal { max-width: 440px; width: 100%; }
    .modal-desc { font-size: 0.88rem; color: var(--text-muted); margin-bottom: 1rem; }
    .modal-actions { display: flex; justify-content: flex-end; gap: 0.7rem; margin-top: 0.6rem; }
  `],
})
export class AdminRequestsComponent implements OnInit {
  requests: MaintenanceRequest[] = [];
  page = 0;
  size = 5;
  totalPages = 0;
  loading = false;
  error = '';
  statusFilter = '';

  decisionTarget: MaintenanceRequest | null = null;
  decisionAction: 'approve' | 'reject' | null = null;
  remarks = '';
  saving = false;

  constructor(private requestService: RequestService) {}

  ngOnInit(): void {
    this.reload();
  }

  reload(): void {
    this.loading = true;
    this.error = '';
    this.requestService.list(this.page, this.size, this.statusFilter || undefined).subscribe({
      next: (res) => {
        this.requests = res.content;
        this.totalPages = res.totalPages;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load requests.';
        this.loading = false;
      },
    });
  }

  onPageChange(p: number): void {
    this.page = p;
    this.reload();
  }

  decide(req: MaintenanceRequest, action: 'approve' | 'reject'): void {
    this.decisionTarget = req;
    this.decisionAction = action;
    this.remarks = '';
  }

  cancelDecision(): void {
    this.decisionTarget = null;
    this.decisionAction = null;
  }

  confirmDecision(): void {
    if (!this.decisionTarget || !this.decisionAction) return;
    this.saving = true;
    const obs =
      this.decisionAction === 'approve'
        ? this.requestService.approve(this.decisionTarget.id!, this.remarks)
        : this.requestService.reject(this.decisionTarget.id!, this.remarks);

    obs.subscribe({
      next: () => {
        this.saving = false;
        this.cancelDecision();
        this.reload();
      },
      error: () => {
        this.saving = false;
        this.error = 'Failed to update request.';
      },
    });
  }
}
