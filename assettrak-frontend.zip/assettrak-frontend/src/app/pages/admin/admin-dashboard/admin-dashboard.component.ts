import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { NavbarComponent } from '../../../shared/components/navbar/navbar.component';
import { AssetService } from '../../../core/services/asset.service';
import { EmployeeService } from '../../../core/services/employee.service';
import { RequestService } from '../../../core/services/request.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, NavbarComponent],
  template: `
    <div class="app-shell">
      <app-navbar></app-navbar>
      <div class="page-container">
        <h2>Welcome back, {{ auth.currentUser()?.fullName }} 👋</h2>
        <p class="subtitle">Here's what's happening across your organization.</p>

        <div class="stats-grid">
          <div class="card stat-card">
            <span class="stat-label">Total Assets</span>
            <span class="stat-value">{{ totalAssets }}</span>
          </div>
          <div class="card stat-card">
            <span class="stat-label">Total Employees</span>
            <span class="stat-value">{{ totalEmployees }}</span>
          </div>
          <div class="card stat-card">
            <span class="stat-label">Pending Requests</span>
            <span class="stat-value">{{ pendingRequests }}</span>
          </div>
          <div class="card stat-card">
            <span class="stat-label">Total Requests</span>
            <span class="stat-value">{{ totalRequests }}</span>
          </div>
        </div>

        <div class="quick-links">
          <a routerLink="/admin/assets" class="card link-card">
            <span class="icon">🗂️</span>
            <div><h3>Manage Assets</h3><p>Add, edit, assign, or retire assets</p></div>
          </a>
          <a routerLink="/admin/employees" class="card link-card">
            <span class="icon">👥</span>
            <div><h3>Manage Employees</h3><p>Maintain employee records</p></div>
          </a>
          <a routerLink="/admin/requests" class="card link-card">
            <span class="icon">🛠️</span>
            <div><h3>Maintenance Requests</h3><p>Review, approve or reject requests</p></div>
          </a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    h2 { color: #fff; margin-bottom: 0.2rem; }
    .subtitle { color: rgba(255,255,255,0.85); margin-bottom: 1.8rem; }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 1.2rem;
      margin-bottom: 2rem;
    }
    .quick-links {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 1.2rem;
    }
    .link-card {
      display: flex;
      align-items: center;
      gap: 1rem;
      text-decoration: none;
      color: inherit;
    }
    .link-card .icon { font-size: 1.8rem; }
    .link-card h3 { font-size: 1rem; margin-bottom: 0.2rem; }
    .link-card p { font-size: 0.85rem; color: var(--text-muted); }
  `],
})
export class AdminDashboardComponent implements OnInit {
  totalAssets = 0;
  totalEmployees = 0;
  pendingRequests = 0;
  totalRequests = 0;

  constructor(
    public auth: AuthService,
    private assetService: AssetService,
    private employeeService: EmployeeService,
    private requestService: RequestService
  ) {}

  ngOnInit(): void {
    forkJoin({
      assets: this.assetService.list(0, 1),
      employees: this.employeeService.list(0, 1),
      requests: this.requestService.list(0, 1),
      pending: this.requestService.list(0, 1, 'PENDING'),
    }).subscribe((res) => {
      this.totalAssets = res.assets.totalElements;
      this.totalEmployees = res.employees.totalElements;
      this.totalRequests = res.requests.totalElements;
      this.pendingRequests = res.pending.totalElements;
    });
  }
}
