import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NavbarComponent } from '../../../shared/components/navbar/navbar.component';
import { PaginationComponent } from '../../../shared/components/pagination/pagination.component';
import { RequestService } from '../../../core/services/request.service';
import { AssetService } from '../../../core/services/asset.service';
import { Asset, MaintenanceRequest } from '../../../core/models/models';

@Component({
  selector: 'app-my-requests',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent, PaginationComponent],
  template: `
    <div class="app-shell">
      <app-navbar></app-navbar>
      <div class="page-container">
        <h2 class="page-title">My Maintenance Requests</h2>
        <p class="page-subtitle">Raise a new request or track your existing ones</p>

        <div class="card form-card">
          <h3>Raise a New Request</h3>
          <div class="alert alert-danger" *ngIf="formError">{{ formError }}</div>
          <div class="alert alert-success" *ngIf="formSuccess">Request submitted successfully!</div>

          <form [formGroup]="form" (ngSubmit)="submit()">
            <div class="form-row">
              <div class="form-group">
                <label>Asset</label>
                <select class="form-control" formControlName="assetId" [class.is-invalid]="isInvalid('assetId')">
                  <option [ngValue]="null" disabled>Select one of your assets</option>
                  <option *ngFor="let asset of myAssets" [ngValue]="asset.id">
                    {{ asset.name }} ({{ asset.serialNumber }})
                  </option>
                </select>
                <span class="error-text" *ngIf="isInvalid('assetId')">Please select an asset</span>
              </div>
            </div>
            <div class="form-group">
              <label>Description</label>
              <textarea
                class="form-control"
                rows="3"
                formControlName="description"
                [class.is-invalid]="isInvalid('description')"
                placeholder="Describe the issue..."></textarea>
              <span class="error-text" *ngIf="isInvalid('description')">Please describe the issue (min 10 characters)</span>
            </div>
            <button type="submit" class="btn btn-primary" [disabled]="submitting">
              {{ submitting ? 'Submitting...' : 'Submit Request' }}
            </button>
          </form>
        </div>

        <h3 class="section-title">Request History</h3>
        <div class="alert alert-danger" *ngIf="listError">{{ listError }}</div>

        <div class="card table-card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Asset</th><th>Description</th><th>Status</th><th>Requested On</th><th>Remarks</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let req of requests">
                  <td>{{ req.assetName }}</td>
                  <td class="desc-cell">{{ req.description }}</td>
                  <td><span class="badge" [ngClass]="'badge-' + (req.status || '').toLowerCase()">{{ req.status }}</span></td>
                  <td>{{ req.requestDate | date: 'medium' }}</td>
                  <td>{{ req.adminRemarks || '—' }}</td>
                </tr>
                <tr *ngIf="!requests.length && !loading">
                  <td colspan="5" class="empty">You haven't raised any requests yet.</td>
                </tr>
              </tbody>
            </table>
          </div>
          <app-pagination [page]="page" [totalPages]="totalPages" (pageChange)="onPageChange($event)"></app-pagination>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-title { color: #fff; margin-bottom: 0.15rem; }
    .page-subtitle { color: rgba(255,255,255,0.85); font-size: 0.9rem; margin-bottom: 1.5rem; }
    .form-card { margin-bottom: 2rem; }
    .form-card h3 { margin-bottom: 1rem; }
    .section-title { color: #fff; margin-bottom: 1rem; }
    .table-card { padding: 1.2rem; }
    .desc-cell { max-width: 260px; }
    .empty { text-align: center; color: var(--text-muted); padding: 2rem 0; }
  `],
})
export class MyRequestsComponent implements OnInit {
  myAssets: Asset[] = [];
  requests: MaintenanceRequest[] = [];
  page = 0;
  size = 5;
  totalPages = 0;
  loading = false;
  listError = '';

  submitting = false;
  formError = '';
  formSuccess = false;

  form = this.fb.group({
    assetId: [null as number | null, Validators.required],
    description: ['', [Validators.required, Validators.minLength(10)]],
  });

  constructor(
    private fb: FormBuilder,
    private requestService: RequestService,
    private assetService: AssetService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.assetService.myAssets(0, 100).subscribe((res) => {
      this.myAssets = res.content;
      const preselect = this.route.snapshot.queryParamMap.get('assetId');
      if (preselect) {
        this.form.patchValue({ assetId: Number(preselect) });
      }
    });
    this.reload();
  }

  isInvalid(name: string): boolean {
    const c = this.form.get(name);
    return !!c && c.invalid && (c.dirty || c.touched);
  }

  reload(): void {
    this.loading = true;
    this.listError = '';
    this.requestService.myRequests(this.page, this.size).subscribe({
      next: (res) => {
        this.requests = res.content;
        this.totalPages = res.totalPages;
        this.loading = false;
      },
      error: () => {
        this.listError = 'Failed to load your requests.';
        this.loading = false;
      },
    });
  }

  onPageChange(p: number): void {
    this.page = p;
    this.reload();
  }

  submit(): void {
    this.formError = '';
    this.formSuccess = false;
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting = true;
    const { assetId, description } = this.form.getRawValue();
    this.requestService.create({ assetId: assetId!, description: description! }).subscribe({
      next: () => {
        this.submitting = false;
        this.formSuccess = true;
        this.form.reset({ assetId: null, description: '' });
        this.page = 0;
        this.reload();
        setTimeout(() => (this.formSuccess = false), 3000);
      },
      error: (err) => {
        this.submitting = false;
        this.formError = err?.error?.message || 'Failed to submit request.';
      },
    });
  }
}
