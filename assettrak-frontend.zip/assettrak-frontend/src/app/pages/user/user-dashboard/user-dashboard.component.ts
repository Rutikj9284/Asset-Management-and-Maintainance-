import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { NavbarComponent } from '../../../shared/components/navbar/navbar.component';
import { AssetService } from '../../../core/services/asset.service';
import { RequestService } from '../../../core/services/request.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, NavbarComponent],
  template: `
    <div class="app-shell">
      <app-navbar></app-navbar>
      <div class="page-container">
        <h2>Welcome, {{ auth.currentUser()?.fullName }} 👋</h2>
        <p class="subtitle">Here's a quick overview of your assets and requests.</p>

        <div class="stats-grid">
          <div class="card stat-card">
            <span class="stat-label">Assigned Assets</span>
            <span class="stat-value">{{ myAssetsCount }}</span>
          </div>
          <div class="card stat-card">
            <span class="stat-label">Pending Requests</span>
            <span class="stat-value">{{ pendingCount }}</span>
          </div>
          <div class="card stat-card">
            <span class="stat-label">Total Requests</span>
            <span class="stat-value">{{ totalRequests }}</span>
          </div>
        </div>

        <div class="quick-links">
          <a routerLink="/user/my-assets" class="card link-card">
            <span class="icon">🗂️</span>
            <div><h3>My Assets</h3><p>View assets currently assigned to you</p></div>
          </a>
          <a routerLink="/user/my-requests" class="card link-card">
            <span class="icon">🛠️</span>
            <div><h3>My Requests</h3><p>Raise or track maintenance requests</p></div>
          </a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    h2 { color: #fff; margin-bottom: 0.2rem; }
    .subtitle { color: rgba(255,255,255,0.85); margin-bottom: 1.8rem; }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 1.2rem;
      margin-bottom: 2rem;
    }
    .quick-links {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 1.2rem;
    }
    .link-card { display: flex; align-items: center; gap: 1rem; text-decoration: none; color: inherit; }
    .link-card .icon { font-size: 1.8rem; }
    .link-card h3 { font-size: 1rem; margin-bottom: 0.2rem; }
    .link-card p { font-size: 0.85rem; color: var(--text-muted); }
  `],
})
export class UserDashboardComponent implements OnInit {
  myAssetsCount = 0;
  pendingCount = 0;
  totalRequests = 0;

  constructor(public auth: AuthService, private assetService: AssetService, private requestService: RequestService) {}

  ngOnInit(): void {
    forkJoin({
      assets: this.assetService.myAssets(0, 1),
      requests: this.requestService.myRequests(0, 50),
    }).subscribe((res) => {
      this.myAssetsCount = res.assets.totalElements;
      this.totalRequests = res.requests.totalElements;
      this.pendingCount = res.requests.content.filter((r) => r.status === 'PENDING').length;
    });
  }
}
