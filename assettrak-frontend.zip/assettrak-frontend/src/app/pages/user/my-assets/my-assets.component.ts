import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavbarComponent } from '../../../shared/components/navbar/navbar.component';
import { PaginationComponent } from '../../../shared/components/pagination/pagination.component';
import { AssetService } from '../../../core/services/asset.service';
import { Asset } from '../../../core/models/models';

@Component({
  selector: 'app-my-assets',
  standalone: true,
  imports: [CommonModule, NavbarComponent, PaginationComponent],
  template: `
    <div class="app-shell">
      <app-navbar></app-navbar>
      <div class="page-container">
        <h2 class="page-title">My Assets</h2>
        <p class="page-subtitle">Assets currently assigned to you</p>

        <div class="alert alert-danger" *ngIf="error">{{ error }}</div>

        <div class="grid" *ngIf="assets.length; else emptyState">
          <div class="card asset-card" *ngFor="let asset of assets">
            <div class="asset-header">
              <h3>{{ asset.name }}</h3>
              <span class="badge" [ngClass]="'badge-' + (asset.status || '').toLowerCase()">{{ asset.status }}</span>
            </div>
            <p class="asset-type">{{ asset.type }}</p>
            <div class="asset-meta">
              <span><strong>Serial:</strong> {{ asset.serialNumber }}</span>
              <span *ngIf="asset.location"><strong>Location:</strong> {{ asset.location }}</span>
              <span *ngIf="asset.purchaseDate"><strong>Purchased:</strong> {{ asset.purchaseDate }}</span>
            </div>
            <button class="btn btn-outline btn-sm" (click)="raiseRequest(asset)">Raise Maintenance Request</button>
          </div>
        </div>

        <ng-template #emptyState>
          <div class="card empty-card" *ngIf="!loading">
            <p>No assets are currently assigned to you.</p>
          </div>
        </ng-template>

        <app-pagination [page]="page" [totalPages]="totalPages" (pageChange)="onPageChange($event)"></app-pagination>
      </div>
    </div>
  `,
  styles: [`
    .page-title { color: #fff; margin-bottom: 0.15rem; }
    .page-subtitle { color: rgba(255,255,255,0.85); font-size: 0.9rem; margin-bottom: 1.5rem; }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 1.2rem;
    }
    .asset-card { display: flex; flex-direction: column; gap: 0.6rem; }
    .asset-header { display: flex; justify-content: space-between; align-items: center; }
    .asset-header h3 { font-size: 1.05rem; }
    .asset-type { color: var(--text-muted); font-size: 0.85rem; }
    .asset-meta { display: flex; flex-direction: column; gap: 0.25rem; font-size: 0.82rem; color: var(--text-dark); margin-bottom: 0.4rem; }
    .empty-card { text-align: center; color: var(--text-muted); }
  `],
})
export class MyAssetsComponent implements OnInit {
  assets: Asset[] = [];
  page = 0;
  size = 6;
  totalPages = 0;
  loading = false;
  error = '';

  constructor(private assetService: AssetService, private router: Router) {}

  ngOnInit(): void {
    this.reload();
  }

  reload(): void {
    this.loading = true;
    this.error = '';
    this.assetService.myAssets(this.page, this.size).subscribe({
      next: (res) => {
        this.assets = res.content;
        this.totalPages = res.totalPages;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load your assets.';
        this.loading = false;
      },
    });
  }

  onPageChange(p: number): void {
    this.page = p;
    this.reload();
  }

  raiseRequest(asset: Asset): void {
    this.router.navigate(['/user/my-requests'], { queryParams: { assetId: asset.id } });
  }
}
