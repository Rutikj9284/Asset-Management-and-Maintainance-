/* ==========================================================================
   AssetTrak — maintenance.js
   Admin-only. Tracks maintenance tickets against assets.
   ========================================================================== */

let maintFilterStatus = '';

function renderMaintenance(){
  qs('#viewRoot').innerHTML = `
    <div class="toolbar">
      <div class="filters">
        <select id="maintStatusFilter">
          <option value="">All Status</option>
          ${['Pending','In Progress','Completed'].map(s=>`<option value="${s}">${s}</option>`).join('')}
        </select>
      </div>
      <button class="btn btn-amber" id="addMaintBtn">+ New Ticket</button>
    </div>
    <div class="data-card">
      <table>
        <thead>
          <tr><th>Asset</th><th>Issue</th><th>Requested</th><th>Scheduled</th><th>Technician</th><th>Cost</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody id="maintTableBody"></tbody>
      </table>
    </div>
  `;
  qs('#maintStatusFilter').addEventListener('change', e => { maintFilterStatus = e.target.value; renderMaintRows(); });
  qs('#addMaintBtn').addEventListener('click', () => openMaintModal());
  renderMaintRows();
}

function renderMaintRows(){
  let list = Store.all('maintenance');
  if (maintFilterStatus) list = list.filter(m => m.status === maintFilterStatus);

  const body = qs('#maintTableBody');
  if (!list.length){
    body.innerHTML = `<tr class="empty-row"><td colspan="8">No maintenance tickets match this filter.</td></tr>`;
    return;
  }

  body.innerHTML = list.map(m => {
    const asset = Store.find('assets', m.assetId);
    return `
    <tr>
      <td class="serial-cell">${asset ? asset.assetTag : '—'}</td>
      <td>${escapeHtml(m.issueDescription)}</td>
      <td>${formatDate(m.requestedDate)}</td>
      <td>${formatDate(m.scheduledDate)}</td>
      <td>${escapeHtml(m.technician || '—')}</td>
      <td>${formatCurrency(m.cost)}</td>
      <td><span class="badge ${statusBadgeClass(m.status)}">${m.status}</span></td>
      <td class="row-actions">
        <button class="btn btn-outline btn-sm" onclick="openMaintModal(${m.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="confirmDeleteMaint(${m.id})">Delete</button>
      </td>
    </tr>`;
  }).join('');
}

function openMaintModal(id){
  if (!Auth.requireAdmin('manage maintenance records')) return;
  const editing = !!id;
  const rec = editing ? Store.find('maintenance', id) : null;
  const assets = Store.all('assets').filter(a => a.status !== 'Retired');

  const html = `
    <div class="modal-head">
      <h3>${editing ? 'Edit Maintenance Ticket' : 'New Maintenance Ticket'}</h3>
      <button class="modal-close" onclick="closeModal()">&times;</button>
    </div>
    <form id="maintForm" novalidate>
      <div class="field">
        <label>Asset *</label>
        <select id="f_maintAsset">
          <option value="">— Select asset —</option>
          ${assets.map(a=>`<option value="${a.id}" ${rec && rec.assetId===a.id?'selected':''}>${a.assetTag} — ${a.name}</option>`).join('')}
        </select>
        <div class="error-msg">Please select an asset.</div>
      </div>
      <div class="field">
        <label>Issue Description *</label>
        <textarea id="f_maintDesc">${rec ? escapeHtml(rec.issueDescription) : ''}</textarea>
        <div class="error-msg">Describe the issue (min 5 characters).</div>
      </div>
      <div class="field-row">
        <div class="field">
          <label>Requested Date *</label>
          <input type="date" id="f_reqDate" value="${rec ? rec.requestedDate : new Date().toISOString().slice(0,10)}">
          <div class="error-msg">Requested date is required.</div>
        </div>
        <div class="field">
          <label>Scheduled Date *</label>
          <input type="date" id="f_schedDate" value="${rec ? rec.scheduledDate : ''}">
          <div class="error-msg">Scheduled date must be on or after the requested date.</div>
        </div>
      </div>
      <div class="field-row">
        <div class="field">
          <label>Technician</label>
          <input type="text" id="f_tech" value="${rec ? escapeHtml(rec.technician || '') : ''}">
        </div>
        <div class="field">
          <label>Cost (₹)</label>
          <input type="number" id="f_maintCost" min="0" value="${rec ? rec.cost : 0}">
          <div class="error-msg">Cost cannot be negative.</div>
        </div>
      </div>
      <div class="field">
        <label>Status *</label>
        <select id="f_maintStatus">
          ${['Pending','In Progress','Completed'].map(s=>`<option ${rec && rec.status===s?'selected':''}>${s}</option>`).join('')}
        </select>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">${editing ? 'Save Changes' : 'Create Ticket'}</button>
      </div>
    </form>
  `;
  openModal(html);
  qs('#maintForm').addEventListener('submit', function(e){
    e.preventDefault();
    saveMaint(editing ? id : null);
  });
}

function saveMaint(id){
  if (!Auth.requireAdmin('manage maintenance records')) return;
  const form = qs('#maintForm');
  clearFormErrors(form);

  const assetId = qs('#f_maintAsset').value;
  const issueDescription = qs('#f_maintDesc').value.trim();
  const requestedDate = qs('#f_reqDate').value;
  const scheduledDate = qs('#f_schedDate').value;
  const technician = qs('#f_tech').value.trim();
  const cost = qs('#f_maintCost').value;
  const status = qs('#f_maintStatus').value;

  let valid = true;
  if (!Validate.required(assetId)){ setFieldError(qs('#f_maintAsset'), 'Please select an asset.'); valid = false; }
  if (!Validate.minLen(issueDescription, 5)){ setFieldError(qs('#f_maintDesc'), 'Describe the issue (min 5 characters).'); valid = false; }
  if (!Validate.required(requestedDate)){ setFieldError(qs('#f_reqDate'), 'Requested date is required.'); valid = false; }
  if (!Validate.required(scheduledDate) || !Validate.dateNotBefore(scheduledDate, requestedDate)){
    setFieldError(qs('#f_schedDate'), 'Scheduled date must be on or after the requested date.');
    valid = false;
  }
  if (cost !== '' && Number(cost) < 0){ setFieldError(qs('#f_maintCost'), 'Cost cannot be negative.'); valid = false; }

  if (!valid) return;

  const record = { assetId:Number(assetId), issueDescription, requestedDate, scheduledDate, technician, cost:Number(cost || 0), status };
  if (id){
    Store.update('maintenance', id, record);
    Toast.show('Maintenance ticket updated.');
  } else {
    Store.insert('maintenance', record);
    Toast.show('Maintenance ticket created.');
  }

  // Keep asset status in sync with an open ticket
  if (status !== 'Completed'){
    Store.update('assets', Number(assetId), { status:'Under Maintenance' });
  }

  closeModal();
  renderMaintRows();
}

function confirmDeleteMaint(id){
  if (!Auth.requireAdmin('delete maintenance records')) return;
  const html = `
    <div class="modal-head"><h3>Delete Ticket</h3><button class="modal-close" onclick="closeModal()">&times;</button></div>
    <p>Are you sure you want to delete this maintenance ticket? This cannot be undone.</p>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn btn-danger" id="confirmDeleteMaintBtn">Delete Ticket</button>
    </div>
  `;
  openModal(html);
  qs('#confirmDeleteMaintBtn').addEventListener('click', () => {
    Store.remove('maintenance', id);
    Toast.show('Maintenance ticket deleted.');
    closeModal();
    renderMaintRows();
  });
}
