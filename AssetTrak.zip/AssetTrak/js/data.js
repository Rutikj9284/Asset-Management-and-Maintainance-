/* ==========================================================================
   AssetTrak — data.js
   LocalStorage-backed data layer. Seeds demo data on first run.
   Entities: users, employees, assets, maintenance, requests
   ========================================================================== */

const DB_KEYS = {
  users: 'at_users',
  employees: 'at_employees',
  assets: 'at_assets',
  maintenance: 'at_maintenance',
  requests: 'at_requests',
  seeded: 'at_seeded_v1'
};

function dbGet(key){
  const raw = localStorage.getItem(key);
  return raw ? JSON.parse(raw) : [];
}
function dbSet(key, value){
  localStorage.setItem(key, JSON.stringify(value));
}
function nextId(list){
  return list.length ? Math.max(...list.map(i => i.id)) + 1 : 1;
}

function seedDatabase(){
  if (localStorage.getItem(DB_KEYS.seeded)) return;

  const employees = [
    { id: 1, empCode:'EMP-1001', name:'Ravi Menon', email:'ravi.menon@company.com', phone:'9876543210', department:'Engineering', designation:'Software Engineer', dateJoined:'2022-03-14', status:'Active' },
    { id: 2, empCode:'EMP-1002', name:'Aisha Kulkarni', email:'aisha.kulkarni@company.com', phone:'9876501234', department:'Engineering', designation:'QA Analyst', dateJoined:'2021-07-01', status:'Active' },
    { id: 3, empCode:'EMP-1003', name:'Daniel Fernandes', email:'daniel.f@company.com', phone:'9876512345', department:'Operations', designation:'Ops Executive', dateJoined:'2023-01-20', status:'Active' },
    { id: 4, empCode:'EMP-1004', name:'Priya Shah', email:'priya.shah@company.com', phone:'9876523456', department:'HR', designation:'HR Associate', dateJoined:'2020-11-05', status:'Inactive' }
  ];

  const assets = [
    { id:1, assetTag:'AST-0001', name:'Dell Latitude 5440', category:'Laptop', purchaseDate:'2023-02-10', cost:78000, status:'Assigned', assignedTo:1 },
    { id:2, assetTag:'AST-0002', name:'HP LaserJet Pro M404', category:'Printer', purchaseDate:'2022-06-18', cost:22000, status:'Available', assignedTo:null },
    { id:3, assetTag:'AST-0003', name:'Logitech MX Master 3S', category:'Peripheral', purchaseDate:'2023-09-01', cost:9500, status:'Assigned', assignedTo:2 },
    { id:4, assetTag:'AST-0004', name:'Dell UltraSharp U2723QE', category:'Monitor', purchaseDate:'2021-12-12', cost:45000, status:'Under Maintenance', assignedTo:3 },
    { id:5, assetTag:'AST-0005', name:'MacBook Pro 14"', category:'Laptop', purchaseDate:'2024-01-22', cost:210000, status:'Available', assignedTo:null },
    { id:6, assetTag:'AST-0006', name:'Cisco Meraki AP', category:'Networking', purchaseDate:'2020-05-30', cost:31000, status:'Retired', assignedTo:null }
  ];

  const maintenance = [
    { id:1, assetId:4, issueDescription:'Screen flickering intermittently', requestedDate:'2026-06-20', scheduledDate:'2026-07-10', status:'In Progress', cost:3500, technician:'Sunil Rao' },
    { id:2, assetId:2, issueDescription:'Toner replacement', requestedDate:'2026-05-02', scheduledDate:'2026-05-05', status:'Completed', cost:1200, technician:'Sunil Rao' }
  ];

  const requests = [
    { id:1, type:'Asset', employeeId:2, details:'Need a second monitor for dual-screen setup', status:'Pending', requestDate:'2026-07-01', assetCategory:'Monitor' },
    { id:2, type:'Maintenance', employeeId:1, details:'Laptop battery draining very fast', status:'Approved', requestDate:'2026-06-28', assetId:1 }
  ];

  const users = [
    { id:1, username:'admin', password:'Admin@123', role:'Admin', name:'System Admin', email:'admin@company.com', employeeId:null },
    { id:2, username:'ravi.menon', password:'Employee@123', role:'Employee', name:'Ravi Menon', email:'ravi.menon@company.com', employeeId:1 },
    { id:3, username:'aisha.kulkarni', password:'Employee@123', role:'Employee', name:'Aisha Kulkarni', email:'aisha.kulkarni@company.com', employeeId:2 }
  ];

  dbSet(DB_KEYS.employees, employees);
  dbSet(DB_KEYS.assets, assets);
  dbSet(DB_KEYS.maintenance, maintenance);
  dbSet(DB_KEYS.requests, requests);
  dbSet(DB_KEYS.users, users);
  localStorage.setItem(DB_KEYS.seeded, 'true');
}

seedDatabase();

/* ---------------- Generic store API ---------------- */
const Store = {
  all(entity){ return dbGet(DB_KEYS[entity]); },
  save(entity, list){ dbSet(DB_KEYS[entity], list); },
  find(entity, id){ return this.all(entity).find(x => x.id === Number(id)); },
  insert(entity, record){
    const list = this.all(entity);
    record.id = nextId(list);
    list.push(record);
    this.save(entity, list);
    return record;
  },
  update(entity, id, patch){
    const list = this.all(entity);
    const idx = list.findIndex(x => x.id === Number(id));
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...patch };
    this.save(entity, list);
    return list[idx];
  },
  remove(entity, id){
    const list = this.all(entity).filter(x => x.id !== Number(id));
    this.save(entity, list);
  }
};
