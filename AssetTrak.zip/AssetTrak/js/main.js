/* ==========================================================================
   AssetTrak — main.js
   Bootstraps the app shell (app.html): guards the session, wires logout,
   renders the sidebar, and starts the router. Also provides shared modal
   open/close helpers used by every view module.
   ========================================================================== */

function openModal(innerHtml){
  let overlay = qs('#modalOverlay');
  if (!overlay){
    overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.id = 'modalOverlay';
    overlay.innerHTML = '<div class="modal" id="modalBody"></div>';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
  }
  qs('#modalBody').innerHTML = innerHtml;
  overlay.classList.add('open');
}

function closeModal(){
  const overlay = qs('#modalOverlay');
  if (overlay) overlay.classList.remove('open');
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});

function initApp(){
  Auth.requireLogin();
  if (!Auth.isLoggedIn()) return;

  renderSidebar();
  qs('#logoutBtn').addEventListener('click', () => Auth.logout());

  if (!window.location.hash) window.location.hash = 'dashboard';
  router();
}

document.addEventListener('DOMContentLoaded', initApp);
