/* ==========================================================================
   AssetTrak — nav.js
   Builds the role-based sidebar and topbar for the app shell.
   ========================================================================== */

const NAV_ITEMS = [
  { view:'dashboard',   label:'Dashboard',        roles:['Admin','Employee'] },
  { view:'assets',      label:'Assets',           roles:['Admin','Employee'] },
  { view:'employees',   label:'Employees',        roles:['Admin'] },
  { view:'maintenance', label:'Maintenance',      roles:['Admin'] },
  { view:'requests',    label:'Requests',         roles:['Admin','Employee'] },
  { view:'reports',     label:'Reports',          roles:['Admin','Employee'] }
];

function renderSidebar(){
  const user = Auth.currentUser();
  const list = qs('#sideNavList');
  if (!list) return;

  list.innerHTML = NAV_ITEMS
    .filter(item => item.roles.includes(user.role))
    .map(item => `<li><a href="#${item.view}" data-view="${item.view}">${item.label}</a></li>`)
    .join('');

  const foot = qs('#sidebarFoot');
  if (foot){
    foot.innerHTML = `
      <div>${escapeHtml(user.name)}</div>
      <span class="role-pill role-${user.role}">${user.role}</span>
    `;
  }
}

function highlightActiveNav(view){
  qsa('#sideNavList a').forEach(a => {
    a.classList.toggle('active', a.dataset.view === view);
  });
}
