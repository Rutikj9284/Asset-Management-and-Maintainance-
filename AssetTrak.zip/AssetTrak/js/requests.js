/* ==========================================================================
   AssetTrak — requests.js
   Employee: submit an Asset or Maintenance request, track own requests.
   Admin: review all requests, approve or reject.
   ========================================================================== */

let reqFilterStatus = '';

function renderRequests(){
  const isAdmin = Auth.isAdmin();
  const user = Auth.currentUser();

  qs('#viewRoot').innerHTML = `
    ${!isAdmin ? `
    <div class="panel">
      <h3>Submit a New Request</h3>
      <form id="newReqForm" novalidate>
        <div class="field-row">
          <div class="field">
            <label>Request Type *</label>
            <select id="f_reqType">
              <option value="Asset">New Asset</option>
              <option value="Maintenance">Maintenance</option>
            </select>
          </div>
          <div class="field" id="reqAssetWrap">
            <label>Related Asset (for maintenance)</label>
            <select id="f_reqAsset">
              <option value="">— Select your asset —</option>
              ${Store.all('assets').filter(a=>a.assignedTo===user.employeeId).map(a=>`<option value="${a.id}">${a.assetTag} — ${a.name}</option>`).join('')}
            </select>
            <div class="error-msg">Please select which asset needs attention.</div>
          </div>
        </div>
        <div class="field">
          <label>Details *</label>
          <textarea id="f_reqDetails" placeholder="Describe what you need..."></textarea>
          <div class="error-msg">Please provide details (min 10 characters).</div>
        </div>
        <button type="submit" class="btn btn-amber">Submit Request</button>
      </form>
    </div>
    ` : ''}

    <div class="toolbar">
      <div class="filters">
        <select id="reqStatusFilter">
          <option value="">All Status</option>
          ${['Pending','Approved','Rejected'].map(s=>`<option value="${s}">${s}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="data-card">
      <table>
        <thead>
          <tr>${isAdmin ? '<th>Employee</th>' : ''}<th>Type</th><th>Details</th><th>Date</th><th>Status</th>${isAdmin ? '<th>Actions</th>' : ''}</tr>
        </thead>
        <tbody id="reqTableBody"></tbody>
      </table>
    </div>
  `;

  if (!isAdmin){
    qs('#f_reqType').addEventListener('change', toggleReqAssetField);
    toggleReqAssetField();
    qs('#newReqForm').addEventListener('submit', function(e){
      e.preventDefault();
      submitRequest();
    });
  }

  qs('#reqStatusFilter').addEventListener('change', e => { reqFilterStatus = e.target.value; renderReqRows(); });
  renderReqRows();
}

function toggleReqAssetField(){
  const type = qs('#f_reqType').value;
  qs('#reqAssetWrap').style.display = type === 'Maintenance' ? 'block' : 'none';
}

function renderReqRows(){
  const isAdmin = Auth.isAdmin();
  const user = Auth.currentUser();
  let list = isAdmin ? Store.all('requests') : Store.all('requests').filter(r => r.employeeId === user.employeeId);
  if (reqFilterStatus) list = list.filter(r => r.status === reqFilterStatus);
  list = [...list].reverse();

  const body = qs('#reqTableBody');
  const colspan = isAdmin ? 5 : 4;
  if (!list.length){
    body.innerHTML = `<tr class="empty-row"><td colspan="${colspan}">No requests to show.</td></tr>`;
    return;
  }

  body.innerHTML = list.map(r => {
    const emp = Store.find('employees', r.employeeId);
    return `
    <tr>
      ${isAdmin ? `<td>${emp ? escapeHtml(emp.name) : '—'}</td>` : ''}
      <td>${r.type}</td>
      <td>${escapeHtml(r.details)}</td>
      <td>${formatDate(r.requestDate)}</td>
      ${isAdmin ? `
      <td class="row-actions">
        <span class="badge ${statusBadgeClass(r.status)}" style="margin-right:8px;">${r.status}</span>
        ${r.status === 'Pending' ? `
          <button class="btn btn-outline btn-sm" onclick="reviewRequest(${r.id}, 'Approved')">Approve</button>
          <button class="btn btn-danger btn-sm" onclick="reviewRequest(${r.id}, 'Rejected')">Reject</button>
        ` : ''}
      </td>` : `<td><span class="badge ${statusBadgeClass(r.status)}">${r.status}</span></td>`}
    </tr>`;
  }).join('');
}

function submitRequest(){
  const user = Auth.currentUser();
  const form = qs('#newReqForm');
  clearFormErrors(form);

  const type = qs('#f_reqType').value;
  const assetId = qs('#f_reqAsset').value;
  const details = qs('#f_reqDetails').value.trim();

  let valid = true;
  if (type === 'Maintenance' && !Validate.required(assetId)){
    setFieldError(qs('#f_reqAsset'), 'Please select which asset needs attention.');
    valid = false;
  }
  if (!Validate.minLen(details, 10)){
    setFieldError(qs('#f_reqDetails'), 'Please provide details (min 10 characters).');
    valid = false;
  }
  if (!valid) return;

  Store.insert('requests', {
    type,
    employeeId: user.employeeId,
    details,
    status:'Pending',
    requestDate: new Date().toISOString().slice(0,10),
    assetId: assetId ? Number(assetId) : null
  });

  Toast.show('Request submitted.');
  form.reset();
  toggleReqAssetField();
  renderReqRows();
}

function reviewRequest(id, decision){
  if (!Auth.requireAdmin('review requests')) return;
  Store.update('requests', id, { status: decision });
  Toast.show(`Request ${decision.toLowerCase()}.`);
  renderReqRows();
}
