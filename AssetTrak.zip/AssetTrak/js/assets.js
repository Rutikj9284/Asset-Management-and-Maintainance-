/* ==========================================================================
   AssetTrak — assets.js
   Admin: full CRUD. Employee: read-only view, can only submit a request.
   ========================================================================== */

let astFilterText = '';
let astFilterCategory = '';
let astFilterStatus = '';

function renderAssets(){
  const isAdmin = Auth.isAdmin();

  qs('#viewRoot').innerHTML = `
    ${!isAdmin ? `<div class="disabled-note">You're viewing Assets in read-only mode. Need something? Use <a href="#requests">Requests</a> to ask for a new asset or maintenance.</div>` : ''}
    <div class="toolbar">
      <div class="filters">
        <input type="text" id="astSearch" class="search-input" placeholder="Search tag or name...">
        <select id="astCategoryFilter">
          <option value="">All Categories</option>
          ${[...new Set(Store.all('assets').map(a=>a.category))].map(c=>`<option value="${c}">${c}</option>`).join('')}
        </select>
        <select id="astStatusFilter">
          <option value="">All Status</option>
          ${['Available','Assigned','Under Maintenance','Retired'].map(s=>`<option value="${s}">${s}</option>`).join('')}
        </select>
      </div>
      ${isAdmin
        ? `<button class="btn btn-amber" id="addAssetBtn">+ Add Asset</button>`
        : `<button class="btn btn-amber" onclick="location.hash='requests'">Request an Asset</button>`}
    </div>
    <div class="data-card">
      <table>
        <thead>
          <tr><th>Asset Tag</th><th>Name</th><th>Category</th><th>Purchase Date</th><th>Cost</th><th>Status</th><th>Assigned To</th>${isAdmin ? '<th>Actions</th>' : ''}</tr>
        </thead>
        <tbody id="astTableBody"></tbody>
      </table>
    </div>
  `;

  qs('#astSearch').addEventListener('input', e => { astFilterText = e.target.value.toLowerCase(); renderAssetRows(); });
  qs('#astCategoryFilter').addEventListener('change', e => { astFilterCategory = e.target.value; renderAssetRows(); });
  qs('#astStatusFilter').addEventListener('change', e => { astFilterStatus = e.target.value; renderAssetRows(); });
  if (isAdmin) qs('#addAssetBtn').addEventListener('click', () => openAssetModal());

  renderAssetRows();
}

function renderAssetRows(){
  const isAdmin = Auth.isAdmin();
  let list = Store.all('assets');
  if (astFilterText){
    list = list.filter(a => a.assetTag.toLowerCase().includes(astFilterText) || a.name.toLowerCase().includes(astFilterText));
  }
  if (astFilterCategory) list = list.filter(a => a.category === astFilterCategory);
  if (astFilterStatus) list = list.filter(a => a.status === astFilterStatus);

  const body = qs('#astTableBody');
  if (!list.length){
    body.innerHTML = `<tr class="empty-row"><td colspan="${isAdmin ? 8 : 7}">No assets match these filters.</td></tr>`;
    return;
  }

  body.innerHTML = list.map(a => {
    const owner = a.assignedTo ? Store.find('employees', a.assignedTo) : null;
    return `
    <tr>
      <td class="serial-cell">${a.assetTag}</td>
      <td>${escapeHtml(a.name)}</td>
      <td>${escapeHtml(a.category)}</td>
      <td>${formatDate(a.purchaseDate)}</td>
      <td>${formatCurrency(a.cost)}</td>
      <td><span class="led ${ledClass(a.status)}"></span>${a.status}</td>
      <td>${owner ? escapeHtml(owner.name) : '—'}</td>
      ${isAdmin ? `
      <td class="row-actions">
        <button class="btn btn-outline btn-sm" onclick="openAssetModal(${a.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="confirmDeleteAsset(${a.id})">Delete</button>
      </td>` : ''}
    </tr>`;
  }).join('');
}

function openAssetModal(id){
  if (!Auth.requireAdmin('manage assets')) return;
  const editing = !!id;
  const asset = editing ? Store.find('assets', id) : null;
  const employees = Store.all('employees').filter(e => e.status === 'Active');

  const html = `
    <div class="modal-head">
      <h3>${editing ? 'Edit Asset' : 'Add Asset'}</h3>
      <button class="modal-close" onclick="closeModal()">&times;</button>
    </div>
    <form id="astForm" novalidate>
      <div class="field-row">
        <div class="field">
          <label>Asset Tag *</label>
          <input type="text" id="f_assetTag" value="${asset ? asset.assetTag : ''}" placeholder="AST-0007">
          <div class="error-msg">Asset tag is required and must be unique.</div>
        </div>
        <div class="field">
          <label>Name *</label>
          <input type="text" id="f_astName" value="${asset ? escapeHtml(asset.name) : ''}">
          <div class="error-msg">Asset name is required.</div>
        </div>
      </div>
      <div class="field-row">
        <div class="field">
          <label>Category *</label>
          <select id="f_category">
            ${['Laptop','Monitor','Printer','Peripheral','Networking','Furniture','Other'].map(c=>`<option ${asset && asset.category===c?'selected':''}>${c}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Purchase Date *</label>
          <input type="date" id="f_purchaseDate" value="${asset ? asset.purchaseDate : ''}" max="${new Date().toISOString().slice(0,10)}">
          <div class="error-msg">Purchase date is required and cannot be in the future.</div>
        </div>
      </div>
      <div class="field-row">
        <div class="field">
          <label>Cost (₹) *</label>
          <input type="number" id="f_cost" min="1" value="${asset ? asset.cost : ''}">
          <div class="error-msg">Enter a valid cost greater than 0.</div>
        </div>
        <div class="field">
          <label>Status *</label>
          <select id="f_astStatus">
            ${['Available','Assigned','Under Maintenance','Retired'].map(s=>`<option ${asset && asset.status===s?'selected':''}>${s}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="field" id="assignedToWrap">
        <label>Assigned To</label>
        <select id="f_assignedTo">
          <option value="">— Not assigned —</option>
          ${employees.map(e=>`<option value="${e.id}" ${asset && asset.assignedTo===e.id?'selected':''}>${e.name} (${e.empCode})</option>`).join('')}
        </select>
        <div class="hint">Required when status is "Assigned".</div>
        <div class="error-msg">Select an employee, or change status away from "Assigned".</div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">${editing ? 'Save Changes' : 'Add Asset'}</button>
      </div>
    </form>
  `;
  openModal(html);
  qs('#astForm').addEventListener('submit', function(e){
    e.preventDefault();
    saveAsset(editing ? id : null);
  });
}

function saveAsset(id){
  if (!Auth.requireAdmin('manage assets')) return;
  const form = qs('#astForm');
  clearFormErrors(form);

  const assetTag = qs('#f_assetTag').value.trim();
  const name = qs('#f_astName').value.trim();
  const category = qs('#f_category').value;
  const purchaseDate = qs('#f_purchaseDate').value;
  const cost = qs('#f_cost').value;
  const status = qs('#f_astStatus').value;
  const assignedToRaw = qs('#f_assignedTo').value;
  const assignedTo = assignedToRaw ? Number(assignedToRaw) : null;

  let valid = true;
  const assets = Store.all('assets');
  const dupTag = assets.find(a => a.assetTag.toLowerCase() === assetTag.toLowerCase() && a.id !== id);

  if (!Validate.required(assetTag) || dupTag){
    setFieldError(qs('#f_assetTag'), dupTag ? 'This asset tag is already in use.' : 'Asset tag is required.');
    valid = false;
  }
  if (!Validate.minLen(name, 2)){ setFieldError(qs('#f_astName'), 'Asset name is required.'); valid = false; }
  if (!Validate.required(purchaseDate) || !Validate.notFutureDate(purchaseDate)){
    setFieldError(qs('#f_purchaseDate'), 'Purchase date is required and cannot be in the future.');
    valid = false;
  }
  if (!Validate.positiveNumber(cost)){ setFieldError(qs('#f_cost'), 'Enter a valid cost greater than 0.'); valid = false; }
  if (status === 'Assigned' && !assignedTo){
    setFieldError(qs('#f_assignedTo'), 'Select an employee for an Assigned asset.');
    valid = false;
  }

  if (!valid) return;

  const record = { assetTag, name, category, purchaseDate, cost:Number(cost), status, assignedTo: status === 'Assigned' ? assignedTo : null };
  if (id){
    Store.update('assets', id, record);
    Toast.show('Asset updated successfully.');
  } else {
    Store.insert('assets', record);
    Toast.show('Asset added successfully.');
  }
  closeModal();
  renderAssetRows();
}

function confirmDeleteAsset(id){
  if (!Auth.requireAdmin('delete assets')) return;
  const asset = Store.find('assets', id);
  const html = `
    <div class="modal-head"><h3>Delete Asset</h3><button class="modal-close" onclick="closeModal()">&times;</button></div>
    <p>Are you sure you want to delete <strong>${escapeHtml(asset.name)}</strong> (${asset.assetTag})? This cannot be undone.</p>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn btn-danger" id="confirmDeleteAstBtn">Delete Asset</button>
    </div>
  `;
  openModal(html);
  qs('#confirmDeleteAstBtn').addEventListener('click', () => {
    Store.remove('assets', id);
    Toast.show('Asset deleted.');
    closeModal();
    renderAssetRows();
  });
}
