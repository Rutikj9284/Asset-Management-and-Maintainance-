/* ==========================================================================
   AssetTrak — auth.js
   Session handled via sessionStorage. Role-based guards used across the app.
   ========================================================================== */

const SESSION_KEY = 'at_session';

const Auth = {
  currentUser(){
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  },
  isLoggedIn(){ return !!this.currentUser(); },
  isAdmin(){
    const u = this.currentUser();
    return !!u && u.role === 'Admin';
  },
  login(username, password){
    const users = Store.all('users');
    const user = users.find(u =>
      u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password
    );
    if (!user) return { ok:false, message:'Incorrect username or password.' };
    const session = { id:user.id, username:user.username, role:user.role, name:user.name, employeeId:user.employeeId };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
    return { ok:true, user: session };
  },
  logout(){
    sessionStorage.removeItem(SESSION_KEY);
    window.location.href = 'login.html';
  },
  requireLogin(){
    if (!this.isLoggedIn()){
      window.location.href = 'login.html';
    }
  },
  /** Guards a mutating action (create/update/delete). Returns true if allowed. */
  requireAdmin(actionLabel){
    if (!this.isAdmin()){
      Toast.show(`Only Admins can ${actionLabel || 'perform this action'}.`, 'error');
      return false;
    }
    return true;
  }
};
