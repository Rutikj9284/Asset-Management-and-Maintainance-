/* ==========================================================================
   AssetTrak — state.js
   Minimal hash router. Each view module exposes a render{ViewName}() function
   that draws into #viewRoot. Routes are guarded by role.
   ========================================================================== */

const ROUTES = {
  dashboard:   { render: () => renderDashboard(),   title:'Dashboard',   roles:['Admin','Employee'] },
  assets:      { render: () => renderAssets(),      title:'Assets',      roles:['Admin','Employee'] },
  employees:   { render: () => renderEmployees(),   title:'Employees',   roles:['Admin'] },
  maintenance: { render: () => renderMaintenance(), title:'Maintenance', roles:['Admin'] },
  requests:    { render: () => renderRequests(),    title:'Requests',    roles:['Admin','Employee'] },
  reports:     { render: () => renderReports(),     title:'Reports',     roles:['Admin','Employee'] }
};

const AppState = {
  currentView: 'dashboard'
};

function router(){
  const user = Auth.currentUser();
  if (!user) { window.location.href = 'login.html'; return; }

  let view = (window.location.hash || '#dashboard').replace('#', '');
  let route = ROUTES[view];

  if (!route || !route.roles.includes(user.role)){
    // Unknown route or not permitted for this role — fall back to dashboard
    view = 'dashboard';
    route = ROUTES.dashboard;
    if (window.location.hash.replace('#','') !== 'dashboard') {
      window.location.hash = 'dashboard';
    }
  }

  AppState.currentView = view;
  qs('#topbarTitle').textContent = route.title;
  highlightActiveNav(view);
  route.render();
}

window.addEventListener('hashchange', router);
