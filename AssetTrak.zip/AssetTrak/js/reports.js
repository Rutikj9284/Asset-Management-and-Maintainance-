/* ==========================================================================
   AssetTrak — reports.js
   Read-only for both roles. Simple aggregate breakdowns rendered as bar rows
   (no external charting library — pure HTML/CSS).
   ========================================================================== */

function barRows(counts, colorClass){
  const max = Math.max(...Object.values(counts), 1);
  return Object.entries(counts).map(([label, count]) => `
    <div style="margin-bottom:14px;">
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:5px;">
        <span>${escapeHtml(label)}</span><span class="mono">${count}</span>
      </div>
      <div style="background:var(--paper-dim); border-radius:4px; height:10px; overflow:hidden;">
        <div style="width:${(count/max*100).toFixed(0)}%; height:100%; background:var(${colorClass});"></div>
      </div>
    </div>
  `).join('');
}

function countBy(list, key){
  return list.reduce((acc, item) => {
    const k = item[key] || 'Unspecified';
    acc[k] = (acc[k] || 0) + 1;
    return acc;
  }, {});
}

function renderReports(){
  const isAdmin = Auth.isAdmin();
  const assets = Store.all('assets');
  const maintenance = Store.all('maintenance');
  const requests = Store.all('requests');
  const employees = Store.all('employees');

  const assetsByStatus = countBy(assets, 'status');
  const assetsByCategory = countBy(assets, 'category');
  const maintByStatus = countBy(maintenance, 'status');
  const totalMaintCost = maintenance.reduce((sum, m) => sum + Number(m.cost || 0), 0);
  const totalAssetValue = assets.reduce((sum, a) => sum + Number(a.cost || 0), 0);

  qs('#viewRoot').innerHTML = `
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Total Asset Value</div>
        <div class="kpi-value">${formatCurrency(totalAssetValue)}</div>
        <div class="kpi-sub">${assets.length} assets tracked</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Maintenance Spend</div>
        <div class="kpi-value">${formatCurrency(totalMaintCost)}</div>
        <div class="kpi-sub">${maintenance.length} tickets logged</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Requests Filed</div>
        <div class="kpi-value">${requests.length}</div>
        <div class="kpi-sub">${requests.filter(r=>r.status==='Pending').length} pending</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">${isAdmin ? 'Workforce' : 'Assets Tracked'}</div>
        <div class="kpi-value">${isAdmin ? employees.length : assets.length}</div>
        <div class="kpi-sub">${isAdmin ? 'across all departments' : 'org-wide'}</div>
      </div>
    </div>

    <div class="field-row" style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
      <div class="panel">
        <h3>Assets by Status</h3>
        ${barRows(assetsByStatus, '--teal')}
      </div>
      <div class="panel">
        <h3>Assets by Category</h3>
        ${barRows(assetsByCategory, '--amber')}
      </div>
    </div>

    <div class="field-row" style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
      <div class="panel">
        <h3>Maintenance Tickets by Status</h3>
        ${barRows(maintByStatus, '--red')}
      </div>
      <div class="panel">
        <h3>Requests by Status</h3>
        ${barRows(countBy(requests, 'status'), '--steel')}
      </div>
    </div>

    ${isAdmin ? `
    <div class="panel">
      <h3>Employees by Department</h3>
      ${barRows(countBy(employees, 'department'), '--teal')}
    </div>` : ''}
  `;
}
