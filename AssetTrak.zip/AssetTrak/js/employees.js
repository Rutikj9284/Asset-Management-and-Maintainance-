/* ==========================================================================
   AssetTrak — employees.js
   Full CRUD, Admin-only. Employee role never reaches this view (router guard),
   but every mutating function double-checks Auth.requireAdmin() as defense in depth.
   ========================================================================== */

let empFilterText = '';
let empFilterDept = '';
let empFilterStatus = '';

function renderEmployees(){
  qs('#viewRoot').innerHTML = `
    <div class="toolbar">
      <div class="filters">
        <input type="text" id="empSearch" class="search-input" placeholder="Search name, code or email...">
        <select id="empDeptFilter">
          <option value="">All Departments</option>
          ${[...new Set(Store.all('employees').map(e=>e.department))].map(d=>`<option value="${d}">${d}</option>`).join('')}
        </select>
        <select id="empStatusFilter">
          <option value="">All Status</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>
      <button class="btn btn-amber" id="addEmpBtn">+ Add Employee</button>
    </div>
    <div class="data-card">
      <table>
        <thead>
          <tr><th>Emp Code</th><th>Name</th><th>Email</th><th>Department</th><th>Designation</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody id="empTableBody"></tbody>
      </table>
    </div>
  `;

  qs('#addEmpBtn').addEventListener('click', () => openEmployeeModal());
  qs('#empSearch').addEventListener('input', e => { empFilterText = e.target.value.toLowerCase(); renderEmployeeRows(); });
  qs('#empDeptFilter').addEventListener('change', e => { empFilterDept = e.target.value; renderEmployeeRows(); });
  qs('#empStatusFilter').addEventListener('change', e => { empFilterStatus = e.target.value; renderEmployeeRows(); });

  renderEmployeeRows();
}

function renderEmployeeRows(){
  let list = Store.all('employees');
  if (empFilterText){
    list = list.filter(e =>
      e.name.toLowerCase().includes(empFilterText) ||
      e.empCode.toLowerCase().includes(empFilterText) ||
      e.email.toLowerCase().includes(empFilterText)
    );
  }
  if (empFilterDept) list = list.filter(e => e.department === empFilterDept);
  if (empFilterStatus) list = list.filter(e => e.status === empFilterStatus);

  const body = qs('#empTableBody');
  if (!list.length){
    body.innerHTML = `<tr class="empty-row"><td colspan="7">No employees match these filters.</td></tr>`;
    return;
  }

  body.innerHTML = list.map(e => `
    <tr>
      <td class="serial-cell">${e.empCode}</td>
      <td>${escapeHtml(e.name)}</td>
      <td>${escapeHtml(e.email)}</td>
      <td>${escapeHtml(e.department)}</td>
      <td>${escapeHtml(e.designation)}</td>
      <td><span class="led ${ledClass(e.status)}"></span>${e.status}</td>
      <td class="row-actions">
        <button class="btn btn-outline btn-sm" onclick="openEmployeeModal(${e.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="confirmDeleteEmployee(${e.id})">Delete</button>
      </td>
    </tr>
  `).join('');
}

function openEmployeeModal(id){
  if (!Auth.requireAdmin('manage employees')) return;
  const editing = !!id;
  const emp = editing ? Store.find('employees', id) : null;

  const html = `
    <div class="modal-head">
      <h3>${editing ? 'Edit Employee' : 'Add Employee'}</h3>
      <button class="modal-close" onclick="closeModal()">&times;</button>
    </div>
    <form id="empForm" novalidate>
      <div class="field-row">
        <div class="field">
          <label>Employee Code *</label>
          <input type="text" id="f_empCode" value="${emp ? emp.empCode : ''}" placeholder="EMP-1005">
          <div class="error-msg">Employee code is required and must be unique.</div>
        </div>
        <div class="field">
          <label>Full Name *</label>
          <input type="text" id="f_name" value="${emp ? escapeHtml(emp.name) : ''}">
          <div class="error-msg">Name is required (min 2 characters).</div>
        </div>
      </div>
      <div class="field-row">
        <div class="field">
          <label>Email *</label>
          <input type="email" id="f_email" value="${emp ? emp.email : ''}">
          <div class="error-msg">Enter a valid email address.</div>
        </div>
        <div class="field">
          <label>Phone *</label>
          <input type="text" id="f_phone" maxlength="10" value="${emp ? emp.phone : ''}" placeholder="10-digit mobile">
          <div class="error-msg">Enter a valid 10-digit Indian mobile number.</div>
        </div>
      </div>
      <div class="field-row">
        <div class="field">
          <label>Department *</label>
          <select id="f_department">
            ${['Engineering','Operations','HR','Finance','Sales'].map(d=>`<option ${emp && emp.department===d?'selected':''}>${d}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Designation *</label>
          <input type="text" id="f_designation" value="${emp ? escapeHtml(emp.designation) : ''}">
          <div class="error-msg">Designation is required.</div>
        </div>
      </div>
      <div class="field-row">
        <div class="field">
          <label>Date Joined *</label>
          <input type="date" id="f_dateJoined" value="${emp ? emp.dateJoined : ''}" max="${new Date().toISOString().slice(0,10)}">
          <div class="error-msg">Date joined cannot be in the future.</div>
        </div>
        <div class="field">
          <label>Status *</label>
          <select id="f_status">
            <option ${emp && emp.status==='Active'?'selected':''}>Active</option>
            <option ${emp && emp.status==='Inactive'?'selected':''}>Inactive</option>
          </select>
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">${editing ? 'Save Changes' : 'Add Employee'}</button>
      </div>
    </form>
  `;
  openModal(html);

  qs('#empForm').addEventListener('submit', function(e){
    e.preventDefault();
    saveEmployee(editing ? id : null);
  });
}

function saveEmployee(id){
  if (!Auth.requireAdmin('manage employees')) return;
  const form = qs('#empForm');
  clearFormErrors(form);

  const empCode = qs('#f_empCode').value.trim();
  const name = qs('#f_name').value.trim();
  const email = qs('#f_email').value.trim();
  const phone = qs('#f_phone').value.trim();
  const department = qs('#f_department').value;
  const designation = qs('#f_designation').value.trim();
  const dateJoined = qs('#f_dateJoined').value;
  const status = qs('#f_status').value;

  let valid = true;
  const employees = Store.all('employees');
  const dupCode = employees.find(e => e.empCode.toLowerCase() === empCode.toLowerCase() && e.id !== id);

  if (!Validate.required(empCode) || dupCode){
    setFieldError(qs('#f_empCode'), dupCode ? 'This employee code is already in use.' : 'Employee code is required.');
    valid = false;
  }
  if (!Validate.minLen(name, 2)){ setFieldError(qs('#f_name'), 'Name is required (min 2 characters).'); valid = false; }
  if (!Validate.email(email)){ setFieldError(qs('#f_email'), 'Enter a valid email address.'); valid = false; }
  if (!Validate.phone(phone)){ setFieldError(qs('#f_phone'), 'Enter a valid 10-digit mobile number.'); valid = false; }
  if (!Validate.required(designation)){ setFieldError(qs('#f_designation'), 'Designation is required.'); valid = false; }
  if (!Validate.required(dateJoined) || !Validate.notFutureDate(dateJoined)){
    setFieldError(qs('#f_dateJoined'), 'Date joined is required and cannot be in the future.');
    valid = false;
  }

  if (!valid) return;

  const record = { empCode, name, email, phone, department, designation, dateJoined, status };
  if (id){
    Store.update('employees', id, record);
    Toast.show('Employee updated successfully.');
  } else {
    Store.insert('employees', record);
    Toast.show('Employee added successfully.');
  }
  closeModal();
  renderEmployeeRows();
}

function confirmDeleteEmployee(id){
  if (!Auth.requireAdmin('delete employees')) return;
  const emp = Store.find('employees', id);
  const assignedAssets = Store.all('assets').filter(a => a.assignedTo === id);

  const html = `
    <div class="modal-head"><h3>Delete Employee</h3><button class="modal-close" onclick="closeModal()">&times;</button></div>
    <p>Are you sure you want to delete <strong>${escapeHtml(emp.name)}</strong> (${emp.empCode})? This cannot be undone.</p>
    ${assignedAssets.length ? `<div class="disabled-note">This employee currently has ${assignedAssets.length} asset(s) assigned. Deleting will unassign them automatically.</div>` : ''}
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn btn-danger" id="confirmDeleteEmpBtn">Delete Employee</button>
    </div>
  `;
  openModal(html);
  qs('#confirmDeleteEmpBtn').addEventListener('click', () => {
    assignedAssets.forEach(a => Store.update('assets', a.id, { status:'Available', assignedTo:null }));
    Store.remove('employees', id);
    Toast.show('Employee deleted.');
    closeModal();
    renderEmployeeRows();
  });
}
