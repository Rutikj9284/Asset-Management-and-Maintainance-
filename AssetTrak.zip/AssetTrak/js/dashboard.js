/* ==========================================================================
   AssetTrak — dashboard.js
   ========================================================================== */

function renderDashboard(){
  const user = Auth.currentUser();
  const assets = Store.all('assets');
  const employees = Store.all('employees');
  const maintenance = Store.all('maintenance');
  const requests = Store.all('requests');

  const available = assets.filter(a => a.status === 'Available').length;
  const assigned = assets.filter(a => a.status === 'Assigned').length;
  const underMaint = assets.filter(a => a.status === 'Under Maintenance').length;
  const pendingReq = requests.filter(r => r.status === 'Pending').length;

  const myRequests = requests.filter(r => r.employeeId === user.employeeId);

  const kpis = Auth.isAdmin() ? `
    <div class="kpi-card">
      <div class="kpi-label">Total Assets</div>
      <div class="kpi-value">${assets.length}</div>
      <div class="kpi-sub">${available} available</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Active Employees</div>
      <div class="kpi-value">${employees.filter(e=>e.status==='Active').length}</div>
      <div class="kpi-sub">${employees.length} total</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Under Maintenance</div>
      <div class="kpi-value">${underMaint}</div>
      <div class="kpi-sub">${maintenance.filter(m=>m.status!=='Completed').length} open tickets</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Pending Requests</div>
      <div class="kpi-value">${pendingReq}</div>
      <div class="kpi-sub">awaiting review</div>
    </div>
  ` : `
    <div class="kpi-card">
      <div class="kpi-label">Assets Available</div>
      <div class="kpi-value">${available}</div>
      <div class="kpi-sub">across the org</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Assigned to Others</div>
      <div class="kpi-value">${assigned}</div>
      <div class="kpi-sub">currently in use</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">My Requests</div>
      <div class="kpi-value">${myRequests.length}</div>
      <div class="kpi-sub">${myRequests.filter(r=>r.status==='Pending').length} pending</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Under Maintenance</div>
      <div class="kpi-value">${underMaint}</div>
      <div class="kpi-sub">org-wide</div>
    </div>
  `;

  const recentMaintRows = maintenance.slice(-5).reverse().map(m => {
    const asset = Store.find('assets', m.assetId);
    return `<tr>
      <td class="serial-cell">${asset ? asset.assetTag : '—'}</td>
      <td>${escapeHtml(m.issueDescription)}</td>
      <td><span class="badge ${statusBadgeClass(m.status)}">${m.status}</span></td>
      <td>${formatDate(m.scheduledDate)}</td>
    </tr>`;
  }).join('') || `<tr class="empty-row"><td colspan="4">No maintenance activity yet.</td></tr>`;

  const recentReqSource = Auth.isAdmin() ? requests : myRequests;
  const recentReqRows = recentReqSource.slice(-5).reverse().map(r => `
    <tr>
      <td>${r.type}</td>
      <td>${escapeHtml(r.details)}</td>
      <td><span class="badge ${statusBadgeClass(r.status)}">${r.status}</span></td>
      <td>${formatDate(r.requestDate)}</td>
    </tr>`).join('') || `<tr class="empty-row"><td colspan="4">No requests yet.</td></tr>`;

  qs('#viewRoot').innerHTML = `
    <div class="kpi-grid">${kpis}</div>

    <div class="panel">
      <h3>Recent Maintenance Activity</h3>
      <div class="data-card">
        <table>
          <thead><tr><th>Asset</th><th>Issue</th><th>Status</th><th>Scheduled</th></tr></thead>
          <tbody>${recentMaintRows}</tbody>
        </table>
      </div>
    </div>

    <div class="panel">
      <h3>${Auth.isAdmin() ? 'Recent Requests (All Employees)' : 'My Recent Requests'}</h3>
      <div class="data-card">
        <table>
          <thead><tr><th>Type</th><th>Details</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>${recentReqRows}</tbody>
        </table>
      </div>
    </div>
  `;
}
