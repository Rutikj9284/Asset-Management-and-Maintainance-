/* ==========================================================================
   AssetTrak — utils.js
   Validation helpers, formatters, toast notifications, small DOM helpers.
   ========================================================================== */

const Toast = {
  ensureWrap(){
    let wrap = document.querySelector('.toast-wrap');
    if (!wrap){
      wrap = document.createElement('div');
      wrap.className = 'toast-wrap';
      document.body.appendChild(wrap);
    }
    return wrap;
  },
  show(message, type = 'success'){
    const wrap = this.ensureWrap();
    const el = document.createElement('div');
    el.className = `toast ${type === 'error' ? 'error' : ''}`;
    el.textContent = message;
    wrap.appendChild(el);
    setTimeout(() => el.remove(), 3200);
  }
};

const Validate = {
  required(value){ return value !== undefined && value !== null && String(value).trim().length > 0; },
  email(value){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value); },
  phone(value){ return /^[6-9]\d{9}$/.test(value); },
  minLen(value, n){ return String(value || '').trim().length >= n; },
  positiveNumber(value){ return !isNaN(value) && Number(value) > 0; },
  notFutureDate(value){
    if (!value) return false;
    return new Date(value) <= new Date();
  },
  dateNotBefore(value, other){
    if (!value || !other) return true;
    return new Date(value) >= new Date(other);
  }
};

/** Applies/clears an inline error on a .field wrapper containing the input. */
function setFieldError(inputEl, message){
  const field = inputEl.closest('.field');
  if (!field) return;
  const msgEl = field.querySelector('.error-msg');
  if (message){
    field.classList.add('invalid');
    if (msgEl) msgEl.textContent = message;
  } else {
    field.classList.remove('invalid');
  }
}

function clearFormErrors(form){
  form.querySelectorAll('.field.invalid').forEach(f => f.classList.remove('invalid'));
}

function formatCurrency(n){
  return '\u20B9' + Number(n || 0).toLocaleString('en-IN');
}

function formatDate(d){
  if (!d) return '—';
  const date = new Date(d);
  return date.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
}

function statusBadgeClass(status){
  const map = {
    Available:'badge-teal', Assigned:'badge-amber', 'Under Maintenance':'badge-red', Retired:'badge-steel',
    Active:'badge-teal', Inactive:'badge-steel',
    Pending:'badge-amber', 'In Progress':'badge-amber', Completed:'badge-teal',
    Approved:'badge-teal', Rejected:'badge-red'
  };
  return map[status] || 'badge-steel';
}

function ledClass(status){
  const map = {
    Available:'led-teal', Assigned:'led-amber', 'Under Maintenance':'led-red', Retired:'led-steel',
    Active:'led-teal', Inactive:'led-steel'
  };
  return map[status] || 'led-steel';
}

function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function qs(sel, ctx){ return (ctx || document).querySelector(sel); }
function qsa(sel, ctx){ return Array.from((ctx || document).querySelectorAll(sel)); }
